import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import complaintsRoutes from "./src/backend/routes/complaintsRoutes";

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json());

  // Backend API Routes
  app.use("/api/complaints", complaintsRoutes);

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "Server is running smoothly" });
  });

  app.post("/api/categorize", async (req, res) => {
    try {
      const { description } = req.body;
      if (!description) {
        return res.status(400).json({ error: "Description is required" });
      }

      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({ error: "Gemini API key is not configured" });
      }

      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Analyze the following civic issue description and categorize it into exactly one of these predefined categories: 'Roads & Streets', 'Water & Plumbing', 'Electricity & Lighting', 'Parks & Recreation', or 'Other'. Respond with ONLY the exact category name, nothing else. Description: "${description}"`,
        config: {
            temperature: 0.1,
        }
      });
      
      const category = response.text?.trim() || 'Other';
      
      const validCategories = ['Roads & Streets', 'Water & Plumbing', 'Electricity & Lighting', 'Parks & Recreation', 'Other'];
      const finalCategory = validCategories.includes(category) ? category : 'Other';

      res.json({ category: finalCategory });
    } catch (error) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: "Failed to categorize" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
