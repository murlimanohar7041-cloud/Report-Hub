import React, { useRef, useState } from 'react';
import { X, Download, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import jsPDF from 'jspdf';
import * as htmlToImage from 'html-to-image';

interface InvoicePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  report: any;
  authorName: string;
}

export default function InvoicePreviewModal({ isOpen, onClose, report, authorName }: InvoicePreviewModalProps) {
  const invoiceRef = useRef<HTMLDivElement>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // No longer needed: style={{ width: '210mm', ... }}
  // We will move this to a dynamic scale
  
  const handleDownload = async () => {
    if (!invoiceRef.current) return;
    setIsGenerating(true);
    
    try {
      // Temporarily remove transform and set static position for accurate capture
      const originalTransform = invoiceRef.current.style.transform;
      const originalTransformOrigin = invoiceRef.current.style.transformOrigin;
      const originalPosition = invoiceRef.current.style.position;
      const originalZIndex = invoiceRef.current.style.zIndex;
      
      invoiceRef.current.style.transform = 'none';
      invoiceRef.current.style.transformOrigin = 'initial';
      
      // Temporarily add a class to fix any dark mode issues inside the canvas
      const originalClass = invoiceRef.current.className;
      invoiceRef.current.className = `${originalClass} bg-white`;

      // Use htmlToImage to capture the full element without clipping
      const dataUrl = await htmlToImage.toPng(invoiceRef.current, {
        backgroundColor: '#ffffff',
        pixelRatio: 2, // 2 is enough for clear text while keeping file size reasonable
        // Note: Removing width/height forces it to use natural dimensions
      });
      
      invoiceRef.current.className = originalClass;
      invoiceRef.current.style.transform = originalTransform;
      invoiceRef.current.style.transformOrigin = originalTransformOrigin;
      invoiceRef.current.style.position = originalPosition;
      invoiceRef.current.style.zIndex = originalZIndex;
      
      // Load image to get dimensions
      const img = new Image();
      img.src = dataUrl;
      await new Promise((resolve) => { img.onload = resolve; });
      
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (img.height * pdfWidth) / img.width;
      
      // If content is longer than A4, it will be scaled down to fit width
      // We use the calculated height to ensure nothing is cut off
      pdf.addImage(dataUrl, 'PNG', 0, 0, pdfWidth, Math.min(pdfHeight, 297)); 
      
      // If it's much taller than A4, we might need to adjust or just let it fit width
      // For invoices, fitting width is usually best. 
      // If we strictly want A4 (297 height), we should ensure aspect ratio.
      
      pdf.save(`Report_Hub_Invoice_${report.id.substring(0,6)}.pdf`);
    } catch (error) {
      console.error("Error generating PDF:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-0 sm:p-4">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-slate-900/80 backdrop-blur-md"
        />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative bg-white dark:bg-slate-900 sm:rounded-3xl shadow-2xl w-full max-w-4xl max-h-[100vh] sm:max-h-[90vh] flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="flex justify-between items-center p-4 sm:p-6 border-b border-slate-100 dark:border-slate-800 shrink-0">
            <h2 className="text-xl font-bold flex items-center gap-2 dark:text-white">
              <FileText className="w-5 h-5 text-indigo-500" />
              Invoice Preview
            </h2>
            <button onClick={onClose} className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          {/* Content area with horizontal scroll hide and vertical scroll */}
          <div 
            ref={containerRef}
            className="p-4 bg-slate-50 dark:bg-slate-950 flex-1 overflow-auto flex justify-center items-start scrollbar-hide"
          >
             <div className="py-8">
                <div 
                  ref={invoiceRef}
                  className="bg-white text-slate-900 shadow-2xl rounded-lg relative origin-top transform scale-[0.4] min-[400px]:scale-[0.45] min-[500px]:scale-[0.55] sm:scale-[0.7] md:scale-[0.85] lg:scale-100"
                  style={{ 
                    width: '794px', // 210mm at 96dpi
                    minHeight: '1123px', // 297mm at 96dpi
                    padding: '60px 40px',
                  }}
                >
                   {/* Decorative border */}
                   <div className="absolute top-0 left-0 w-full h-3 bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-500"></div>

                   {/* Invoice Design */}
                   <div className="flex flex-row justify-between items-start mb-16 pt-8">
                      <div>
                        <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600 tracking-tighter uppercase mb-2">Report Hub</h1>
                        <p className="text-slate-500 text-sm font-bold tracking-[0.2em] uppercase">Resolution Document</p>
                      </div>
                      <div className="text-right">
                        <div className="inline-block bg-slate-900 text-white px-4 py-1 text-xs font-black mb-2 rounded">OFFICIAL INVOICE</div>
                        <p className="font-bold text-slate-800 text-lg">#{report.id.substring(0, 8).toUpperCase()}</p>
                        <p className="text-slate-500 text-xs mt-1 font-mono uppercase">DATE: {new Date().toLocaleDateString()}</p>
                      </div>
                   </div>

                   <div className="grid grid-cols-2 gap-12 mb-16 border-y border-slate-100 py-8">
                     <div>
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3">BILL TO</p>
                       <p className="font-extrabold text-slate-950 text-xl leading-tight">{authorName}</p>
                       <p className="text-slate-500 text-xs mt-2 uppercase font-mono">ID: {report.authorId?.substring(0, 10).toUpperCase() || 'CITIZEN_USER'}</p>
                     </div>
                     <div className="text-right">
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3">PROVIDER</p>
                       <p className="font-extrabold text-slate-950 text-xl leading-tight">Report Hub Services</p>
                       <p className="text-slate-500 text-xs mt-2 uppercase font-mono">DEPT: CIVIC_ADMIN_HQ</p>
                     </div>
                   </div>

                   <div className="mb-16">
                      <div className="bg-slate-50 rounded-3xl p-8 mb-8 border border-slate-100 shadow-inner">
                        <div className="flex justify-between items-center mb-6 border-b border-white pb-6">
                           <h3 className="font-black text-slate-900 text-lg uppercase tracking-tight flex items-center gap-2">
                              <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
                              Case Summary
                           </h3>
                           <span className="bg-emerald-500 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest leading-none">Status: RESOLVED</span>
                        </div>
                        <div className="grid grid-cols-2 gap-8 text-sm">
                          <div className="col-span-2 sm:col-span-1">
                            <span className="text-slate-400 block text-[10px] uppercase font-black tracking-widest mb-2">Issue Identifier</span>
                            <span className="text-slate-900 font-extrabold text-lg leading-tight">{report.title}</span>
                          </div>
                          <div className="col-span-2 sm:col-span-1">
                            <span className="text-slate-400 block text-[10px] uppercase font-black tracking-widest mb-2">Service Category</span>
                            <span className="text-slate-900 font-bold uppercase tracking-tight inline-flex items-center px-4 py-1.5 rounded-xl bg-white shadow-sm border border-slate-100 mt-1">{report.category}</span>
                          </div>
                          <div className="col-span-2">
                            <span className="text-slate-400 block text-[10px] uppercase font-black tracking-widest mb-2">Spatial Reference</span>
                            <span className="text-slate-900 font-bold bg-white px-4 py-3 rounded-2xl border border-slate-100 shadow-sm block mt-1">
                               {report.address ? report.address : (report.location ? `${report.location.lat.toFixed(6)}, ${report.location.lng.toFixed(6)}` : 'Spatial data attached')}
                            </span>
                          </div>
                        </div>
                      </div>
                   
                   <div className="bg-white rounded-3xl border-2 border-slate-900 overflow-hidden shadow-[8px_8px_0px_0px_rgba(0,0,0,0.05)]">
                     <table className="w-full text-sm">
                       <thead className="bg-slate-900 text-white">
                         <tr>
                           <th className="text-left py-5 px-8 font-black text-[10px] uppercase tracking-[0.3em]">DESCRIPTION OF SERVICES</th>
                           <th className="text-right py-5 px-8 font-black text-[10px] uppercase tracking-[0.3em]">COST (₹)</th>
                         </tr>
                       </thead>
                       <tbody className="divide-y divide-slate-100">
                         <tr>
                           <td className="py-6 px-8 text-slate-800 font-bold">Initial Site Survey & Risk Protocol</td>
                           <td className="py-6 px-8 text-right text-slate-900 font-black tabular-nums">₹ 4,200</td>
                         </tr>
                         <tr>
                           <td className="py-6 px-8 text-slate-800 font-bold">Field Engineering & Resolution Personnel</td>
                           <td className="py-6 px-8 text-right text-slate-900 font-black tabular-nums">₹ 10,500</td>
                         </tr>
                         <tr>
                           <td className="py-6 px-8 text-slate-800 font-bold">Component Allocation & Logistical Overhead</td>
                           <td className="py-6 px-8 text-right text-slate-900 font-black tabular-nums">₹ 3,800</td>
                         </tr>
                         <tr className="bg-emerald-50/50">
                           <td className="py-6 px-8 text-emerald-700 font-black italic underline decoration-2 underline-offset-4">Community Impact Credit (Verified Report)</td>
                           <td className="py-6 px-8 text-right text-emerald-600 font-black tabular-nums">-₹ 18,500</td>
                         </tr>
                       </tbody>
                       <tfoot className="bg-slate-50 border-t-2 border-slate-900">
                         <tr>
                           <td className="py-8 px-8 font-black text-lg text-slate-900 tracking-tighter uppercase underline decoration-4 underline-offset-8">TOTAL SETTLEMENT</td>
                           <td className="py-8 px-8 text-right font-black text-slate-900 text-3xl tabular-nums tracking-tighter transition-all hover:scale-105 duration-300">₹ 0.00</td>
                         </tr>
                       </tfoot>
                     </table>
                   </div>
                </div>

                <div className="mt-8 pt-12 border-t-2 border-dotted border-slate-200 flex justify-between items-end">
                  <div className="text-[10px] text-slate-400 max-w-[300px] leading-relaxed">
                    <div className="flex items-center gap-2 mb-4">
                        <div className="w-10 h-10 rounded-2xl bg-slate-900 flex items-center justify-center rotate-3 shadow-lg">
                            <span className="text-white text-xs font-black">RH</span>
                        </div>
                        <div>
                            <span className="font-black text-slate-950 uppercase tracking-widest text-base block leading-none">Report Hub</span>
                            <span className="text-[8px] uppercase font-bold tracking-[0.4em] text-slate-300">Civic Empowerment</span>
                        </div>
                    </div>
                    <p className="font-medium indent-4">This document confirms the successful resolution of the reported issue. No further action is required from the citizen. Report Hub continues to strive for a safer and more efficient community through collaborative transparency.</p>
                  </div>
                  <div className="text-center relative">
                    <div className="absolute -top-16 right-0 w-32 h-32 bg-slate-100 rounded-full -z-10 blur-2xl opacity-50"></div>
                    <div className="font-['Space_Grotesk'] italic text-4xl text-slate-950 mb-3 pr-4 text-right transform -rotate-3 select-none">
                      Murli Manohar kumar
                    </div>
                    <div className="w-64 border-b-4 border-slate-950 pb-4 mb-2"></div>
                    <p className="font-black text-slate-950 text-xs tracking-[0.3em] uppercase">Auth. Signature</p>
                    <p className="text-slate-400 text-[9px] font-bold mt-1 uppercase tracking-widest">Admin Council • Report Hub</p>
                  </div>
                </div>

                {/* Verification Stamp */}
                <div className="absolute bottom-40 right-10 rotate-12 opacity-10 pointer-events-none">
                   <div className="border-4 border-emerald-600 rounded-full w-32 h-32 flex items-center justify-center p-4">
                      <div className="border-2 border-emerald-600 rounded-full w-full h-full flex items-center justify-center text-center">
                         <span className="text-emerald-600 font-black text-[10px] leading-tight uppercase tracking-tighter">VERIFIED<br/>RESOLUTION</span>
                      </div>
                   </div>
                </div>

                {/* Decorative Elements */}
                <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-50/30 rounded-bl-full -z-10 blur-3xl"></div>
                <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-50/30 rounded-tr-full -z-10 blur-3xl"></div>
             </div>
          </div>
        </div>
          
          {/* Footer Action */}
          <div className="p-4 sm:p-6 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row justify-end gap-3 bg-white dark:bg-slate-900 shrink-0">
             <button 
               onClick={onClose}
               disabled={isGenerating}
               className="px-5 py-2.5 rounded-full font-bold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors disabled:opacity-50"
             >
               Cancel
             </button>
             <button 
               onClick={handleDownload}
               disabled={isGenerating}
               className="px-6 py-2.5 rounded-full font-bold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/50 hover:-translate-y-0.5 transition-all flex items-center gap-2 disabled:opacity-70 disabled:hover:translate-y-0"
             >
               {isGenerating ? (
                 <>
                   <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                   Generating PDF...
                 </>
               ) : (
                 <>
                   <Download className="w-4 h-4" /> Download PDF
                 </>
               )}
             </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
