import { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, onSnapshot, getDoc, doc, setDoc, deleteDoc, updateDoc, increment, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import ReportCard from './ReportCard';
import SkeletonCard from './SkeletonCard';
import ReportDetailsModal from './ReportDetailsModal';
import { useAuth } from './AuthProvider';
import { notify } from '../lib/notify';

export default function RecentReports({ onViewAllClick }: { onViewAllClick?: () => void }) {
  const [recentReports, setRecentReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const { t } = useTranslation();
  const { user } = useAuth();

  useEffect(() => {
    const q = query(collection(db, 'reports'), orderBy('createdAt', 'desc'), limit(3));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedReports = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        timeAgo: doc.data().createdAt ? new Date(doc.data().createdAt.toDate()).toLocaleDateString() : 'Just now'
      }));
      setRecentReports(fetchedReports);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const handleUpvote = async (reportId: string, authorId: string, currentUpvotes: number) => {
    if (!user) {
      notify({ message: "Please login to upvote", type: 'error' });
      return;
    }
    
    const upvoteRef = doc(db, `reports/${reportId}/upvotes/${user.uid}`);
    const upvoteSnap = await getDoc(upvoteRef);
    const reportRef = doc(db, 'reports', reportId);

    if (upvoteSnap.exists()) {
      await deleteDoc(upvoteRef);
      await updateDoc(reportRef, { upvoteCount: increment(-1) });
      notify({ message: "Removed upvote" });
    } else {
      await setDoc(upvoteRef, { createdAt: serverTimestamp() });
      await updateDoc(reportRef, { upvoteCount: increment(1) });
      notify({ message: "Added upvote" });
    }
  };

  return (
    <section className="py-12 sm:py-20 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-8 sm:mb-12 gap-4">
          <div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight uppercase text-gradient mb-2">{t('Recent Reports')}</h2>
            <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 font-medium">See what your neighbors are reporting and track the progress of ongoing fixes in the community.</p>
          </div>
          <button onClick={onViewAllClick} className="hidden sm:block text-sm font-bold text-blue-600 dark:text-blue-400 hover:text-purple-600 dark:hover:text-purple-400 transition-colors whitespace-nowrap">
            {t('All Reports')} &rarr;
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {loading ? (
             Array(3).fill(0).map((_, i) => <SkeletonCard key={i} />)
          ) : (
            recentReports.map((report) => (
              <ReportCard 
                key={report.id} 
                report={report} 
                onClick={() => setSelectedReport(report)} 
                onUpvote={handleUpvote}
              />
            ))
          )}
          {!loading && recentReports.length === 0 && (
             <div className="col-span-full py-12 text-center text-slate-500 font-medium">No recent reports found.</div>
          )}
        </div>
        
        <div className="mt-8 text-center sm:hidden">
          <button onClick={onViewAllClick} className="w-full px-6 py-4 glass-card text-slate-700 dark:text-slate-300 rounded-full font-bold transition-colors">
            {t('All Reports')}
          </button>
        </div>
      </div>
      
      <AnimatePresence>
        {selectedReport && (
          <ReportDetailsModal
            report={selectedReport}
            onClose={() => setSelectedReport(null)}
            onUpvote={handleUpvote}
          />
        )}
      </AnimatePresence>
    </section>
  );
}
