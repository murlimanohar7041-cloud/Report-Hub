import { MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-indigo-600 p-2 rounded-lg">
                <MapPin className="h-5 w-5 text-white" />
              </div>
              <span className="text-2xl font-black tracking-tighter uppercase text-white">Report Hub</span>
            </div>
            <p className="max-w-sm text-slate-400 font-medium">
              Empowering citizens to improve their neighborhoods by easily reporting and tracking local community issues.
            </p>
          </div>
          
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-4">Resources</h4>
            <ul className="space-y-3 font-medium text-slate-400">
              <li><button className="hover:text-white transition-colors">How it works</button></li>
              <li><button className="hover:text-white transition-colors">Safety Tips</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-4">Legal</h4>
            <ul className="space-y-3 font-medium text-slate-400">
              <li><button className="hover:text-white transition-colors">Privacy Policy</button></li>
              <li><button className="hover:text-white transition-colors">Terms of Use</button></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-4">Support</h4>
            <ul className="space-y-4 font-medium text-slate-400">
              <li><button onClick={() => { window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-white transition-colors font-bold text-blue-400">Admin Login</button></li>
              <li>
                <div className="flex flex-col">
                  <span className="text-slate-300 font-bold mb-1">Help Center</span>
                  <a href="tel:+919122993866" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-white transition-colors cursor-pointer text-sm mb-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                    9122993866
                  </a>
                  <a href="mailto:murlimanohar0087@gmail.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-white transition-colors cursor-pointer text-sm border-t border-slate-700/50 pt-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                    murlimanohar0087@gmail.com
                  </a>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-800 mt-12 pt-8 text-sm font-bold text-slate-500 text-center flex flex-col md:flex-row justify-between items-center">
          <div>
            &copy; {new Date().getFullYear()} Report Hub. Developed by Murli Manohar kumar.
          </div>
          <p className="text-sm font-bold flex items-center gap-2 mt-4 md:mt-0">
            <span className="w-2 h-2 bg-emerald-500 rounded-full"></span> All Systems Normal
          </p>
        </div>
      </div>
    </footer>
  );
}
