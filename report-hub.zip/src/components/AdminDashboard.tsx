import { useState, useEffect } from 'react';
import { collection, query, orderBy, onSnapshot, doc, updateDoc, deleteDoc, serverTimestamp, addDoc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthProvider';
import { Trash2, Edit, FileText, Clock, CheckCircle, Users, X, Download } from 'lucide-react';
import { StatusBadge } from './StatusBadge';
import { motion, AnimatePresence } from 'motion/react';
import ConfirmDialog from './ConfirmDialog';
import InvoicePreviewModal from './InvoicePreviewModal';
import { notify } from '../lib/notify';

export default function AdminDashboard() {
  const { user } = useAuth();
  const [reports, setReports] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'reports' | 'users'>('reports');
  const [usersList, setUsersList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [authorProfile, setAuthorProfile] = useState<any>(null);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [reportToDelete, setReportToDelete] = useState<string | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);

  useEffect(() => {
    if (user?.role !== 'admin') return;

    const q = query(collection(db, 'reports'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedReports = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        timeAgo: doc.data().createdAt ? new Date(doc.data().createdAt.toDate()).toLocaleDateString() : 'Just now'
      }));
      setReports(fetchedReports);
      setLoading(false);
      
      // Update selected report if it exists in the new list to reflect changes in real-time
      if (selectedReport) {
        const updated = fetchedReports.find(r => r.id === selectedReport.id);
        if (updated) setSelectedReport(updated);
      }
    });

    // Fetch users list
    setLoadingUsers(true);
    const usersQ = query(collection(db, 'users'));
    const unsubscribeUsers = onSnapshot(usersQ, (snapshot) => {
        const users = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        // Ensure they are sorted somehow locally
        users.sort((a: any, b: any) => {
            const timeA = a.lastLogin ? a.lastLogin.toDate().getTime() : (a.createdAt ? a.createdAt.toDate().getTime() : 0);
            const timeB = b.lastLogin ? b.lastLogin.toDate().getTime() : (b.createdAt ? b.createdAt.toDate().getTime() : 0);
            return timeB - timeA;
        });
        setUsersList(users);
        setLoadingUsers(false);
    });

    return () => {
        unsubscribe();
        unsubscribeUsers();
    };
  }, [user, selectedReport?.id]);

  useEffect(() => {
    const fetchAuthor = async () => {
        if (selectedReport?.authorId) {
            const authorRef = doc(db, 'users', selectedReport.authorId);
            const authorDoc = await getDoc(authorRef);
            if (authorDoc.exists()) {
                setAuthorProfile(authorDoc.data());
            } else {
                setAuthorProfile(null);
            }
        } else {
            setAuthorProfile(null);
        }
    };
    fetchAuthor();
  }, [selectedReport?.authorId]);

  const updateStatus = async (reportId: string, authorId: string, reportTitle: string, newStatus: string) => {
    try {
      await updateDoc(doc(db, 'reports', reportId), {
        status: newStatus,
        updatedAt: serverTimestamp()
      });

      // Create notification for the user
      if (authorId) {
        await addDoc(collection(db, 'notifications'), {
          userId: authorId,
          reportId,
          reportTitle,
          newStatus,
          read: false,
          createdAt: serverTimestamp()
        });
      }
      notify({ message: `Status updated to ${newStatus}` });
    } catch (error) {
      console.error("Error updating status: ", error);
      notify({ message: "Failed to update status", type: 'error' });
    }
  };

  const deleteReport = (reportId: string) => {
    setReportToDelete(reportId);
    setShowConfirmDelete(true);
  };

  const confirmDelete = async () => {
    if (!reportToDelete) return;
    setDeleteLoading(true);
    try {
      await deleteDoc(doc(db, 'reports', reportToDelete));
      if (selectedReport?.id === reportToDelete) {
        setSelectedReport(null);
      }
      setShowConfirmDelete(false);
      setReportToDelete(null);
      notify({ message: "Report deleted successfully" });
    } catch (error) {
      console.error("Error deleting report: ", error);
      notify({ message: "Failed to delete report.", type: 'error' });
    } finally {
      setDeleteLoading(false);
    }
  };

  if (user?.role !== 'admin') {
    return <div className="text-center py-20 text-slate-500 dark:text-slate-400">Access Denied</div>;
  }

  return (
    <section className="py-12 relative z-10 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="mb-12">
          <h2 className="text-4xl md:text-5xl font-black tracking-tight uppercase text-gradient mb-4">Admin Dashboard</h2>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <p className="text-xl text-slate-500 dark:text-slate-400 font-medium max-w-2xl">Manage and update all reports and users in the system.</p>
            
            <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200 dark:border-slate-700">
              <button 
                onClick={() => setActiveTab('reports')}
                className={`px-6 py-2 rounded-xl font-bold text-sm transition-all ${activeTab === 'reports' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
              >
                Reports
              </button>
              <button 
                onClick={() => setActiveTab('users')}
                className={`px-6 py-2 rounded-xl font-bold text-sm transition-all ${activeTab === 'users' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
              >
                Users
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-5 rounded-3xl flex items-center justify-between">
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Total Reports</p>
              <h4 className="text-3xl font-black text-slate-900 dark:text-white">{reports.length}</h4>
            </div>
            <div className="p-3 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-2xl">
              <FileText className="w-6 h-6" />
            </div>
          </motion.div>
          
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-card p-5 rounded-3xl flex items-center justify-between">
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Pending</p>
              <h4 className="text-3xl font-black text-amber-600 dark:text-amber-400">{reports.filter(r => r.status === 'open').length}</h4>
            </div>
            <div className="p-3 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-2xl">
              <Clock className="w-6 h-6" />
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-card p-5 rounded-3xl flex items-center justify-between">
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Solved</p>
              <h4 className="text-3xl font-black text-emerald-600 dark:text-emerald-400">{reports.filter(r => r.status === 'resolved').length}</h4>
            </div>
            <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-2xl">
              <CheckCircle className="w-6 h-6" />
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass-card p-5 rounded-3xl flex items-center justify-between">
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Total Users</p>
              <h4 className="text-3xl font-black text-purple-600 dark:text-purple-400">{usersList.length}</h4>
            </div>
            <div className="p-3 bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-2xl">
              <Users className="w-6 h-6" />
            </div>
          </motion.div>
        </div>

        {activeTab === 'reports' ? (
          loading ? (
              <div className="text-center py-12 text-slate-500">Loading reports...</div>
          ) : (
            <motion.div initial={{opacity:0, y: 20}} animate={{opacity:1, y: 0}} className="glass-card overflow-hidden rounded-3xl">
              <ul role="list" className="divide-y divide-slate-200 dark:divide-slate-700/50">
                {reports.map((report) => (
                  <motion.li 
                    key={report.id} 
                    initial={false}
                    animate={{ 
                      scale: selectedReport?.id === report.id ? 1.02 : 1,
                      backgroundColor: selectedReport?.id === report.id ? 'rgb(239 246 255 / 0.3)' : 'transparent'
                    }}
                    className={`p-6 hover:bg-white/50 dark:hover:bg-slate-800/30 transition-all cursor-pointer border-l-4 group ${selectedReport?.id === report.id ? 'border-blue-500 shadow-lg relative z-10' : 'border-transparent'}`}
                    onClick={() => setSelectedReport(report)}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex-1 min-w-0 pr-4">
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white truncate">{report.title}</h3>
                        <div className="mt-1 flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                          <span className="truncate">{report.category}</span>
                          <span>&middot;</span>
                          <span>{report.timeAgo}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 shrink-0">
                        <StatusBadge status={report.status} />
                        <div className="text-blue-500 font-bold text-[10px] uppercase tracking-widest bg-blue-50 dark:bg-blue-900/30 px-3 py-1.5 rounded-full opacity-0 sm:group-hover:opacity-100 transition-opacity whitespace-nowrap">Manage</div>
                      </div>
                    </div>
                  </motion.li>
                ))}
                {reports.length === 0 && (
                  <li className="p-12 text-center text-slate-500 dark:text-slate-400 font-medium">No reports found.</li>
                )}
              </ul>
            </motion.div>
          )
        ) : (
          loadingUsers ? (
            <div className="text-center py-12 text-slate-500">Loading users...</div>
          ) : (
            <motion.div initial={{opacity:0, y: 20}} animate={{opacity:1, y: 0}} className="glass-card overflow-hidden rounded-3xl">
               <div className="overflow-x-auto">
                 <table className="w-full text-left border-collapse">
                   <thead>
                     <tr className="bg-slate-50/50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700">
                       <th className="p-6 text-[10px] font-black uppercase tracking-widest text-slate-500">User</th>
                       <th className="p-6 text-[10px] font-black uppercase tracking-widest text-slate-500">Contact</th>
                       <th className="p-6 text-[10px] font-black uppercase tracking-widest text-slate-500">Role</th>
                       <th className="p-6 text-[10px] font-black uppercase tracking-widest text-slate-500">Last Login</th>
                     </tr>
                   </thead>
                   <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                     {usersList.map((u) => (
                       <tr key={u.id} className="hover:bg-slate-50/30 dark:hover:bg-slate-800/20 transition-colors">
                         <td className="p-6">
                           <div className="flex items-center gap-3">
                             {u.photoURL ? (
                               <img src={u.photoURL} alt="" className="w-10 h-10 rounded-full border border-slate-200 dark:border-slate-700" />
                             ) : (
                               <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-500">
                                 {u.displayName?.charAt(0) || u.email?.charAt(0) || '?'}
                               </div>
                             )}
                             <div>
                               <p className="font-bold text-slate-900 dark:text-white">{u.displayName || 'Anonymous'}</p>
                               <p className="text-[10px] font-mono text-slate-400">{u.id}</p>
                             </div>
                           </div>
                         </td>
                         <td className="p-6">
                           <p className="text-sm font-medium text-slate-600 dark:text-slate-400">{u.email}</p>
                         </td>
                         <td className="p-6">
                           <span className={`text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full ${u.role === 'admin' ? 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'}`}>
                             {u.role || 'user'}
                           </span>
                         </td>
                         <td className="p-6">
                           <p className="text-sm text-slate-500">{u.lastLogin ? new Date(u.lastLogin.toDate()).toLocaleString() : 'Never'}</p>
                         </td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
            </motion.div>
          )
        )}

        <AnimatePresence>
          {selectedReport && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" 
                onClick={() => setSelectedReport(null)}
              ></motion.div>
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-3xl shadow-2xl relative z-10 overflow-hidden border border-slate-200 dark:border-slate-800"
              >
                <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                  <h3 className="text-xl font-black uppercase tracking-tight text-gradient">Manage Complaint</h3>
                  <button onClick={() => setSelectedReport(null)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                    <X className="w-5 h-5 text-slate-500" />
                  </button>
                </div>

                <div className="p-6 max-h-[70vh] overflow-y-auto">
                  {selectedReport.imageUrl && (
                    <div className="relative mb-6">
                      <img src={selectedReport.imageUrl} alt={selectedReport.title} className="w-full aspect-video object-cover rounded-2xl shadow-lg" />
                      <button 
                        onClick={() => {
                          fetch(selectedReport.imageUrl)
                            .then(response => response.blob())
                            .then(blob => {
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = `report-${selectedReport.id}.jpg`;
                              document.body.appendChild(a);
                              a.click();
                              a.remove();
                              window.URL.revokeObjectURL(url);
                            })
                            .catch(err => console.error('Error downloading file', err));
                        }}
                        className="absolute top-4 right-4 p-2 bg-slate-100/90 dark:bg-slate-800/90 hover:bg-white dark:hover:bg-slate-700 rounded-full transition-colors z-20 backdrop-blur-md shadow-sm"
                        title="Download Image"
                      >
                        <Download className="w-5 h-5 text-slate-700 dark:text-slate-200" />
                      </button>
                    </div>
                  )}
                  
                  <div className="mb-6">
                    <div className="flex items-center gap-2 mb-2">
                      <StatusBadge status={selectedReport.status} />
                      <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-full">{selectedReport.category}</span>
                    </div>
                    <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">{selectedReport.title}</h2>
                    <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-sm">{selectedReport.description}</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                    <div className="glass-card p-4 rounded-2xl">
                      <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-1">User Details</span>
                      {authorProfile ? (
                          <div className="flex items-center gap-2">
                             {authorProfile.photoURL && <img src={authorProfile.photoURL} className="w-5 h-5 rounded-full" />}
                             <p className="text-sm font-bold text-slate-700 dark:text-slate-300 truncate">{authorProfile.email}</p>
                          </div>
                      ) : (
                          <p className="text-sm font-bold text-slate-700 dark:text-slate-300 truncate">ID: {selectedReport.authorId}</p>
                      )}
                      <p className="text-[10px] text-slate-500 mt-1">Submitted: {selectedReport.timeAgo}</p>
                    </div>
                    <div className="glass-card p-4 rounded-2xl">
                      <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-1">Location</span>
                      <p className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                        {selectedReport.location?.lat.toFixed(4)}, {selectedReport.location?.lng.toFixed(4)}
                      </p>
                      <button 
                        className="text-[10px] bg-blue-500 text-white px-2 py-0.5 rounded font-black uppercase tracking-widest hover:bg-blue-600 transition-colors"
                        onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${selectedReport.location.lat},${selectedReport.location.lng}`, '_blank')}
                      >
                        Open Maps
                      </button>
                    </div>
                  </div>

                  <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                    <div className="flex flex-col gap-2">
                       <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Update Status</label>
                       <div className="flex gap-2">
                          <button 
                            onClick={() => updateStatus(selectedReport.id, selectedReport.authorId, selectedReport.title, 'open')}
                            className={`flex-1 py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all ${selectedReport.status === 'open' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}
                          >
                            Pending
                          </button>
                          <button 
                            onClick={() => updateStatus(selectedReport.id, selectedReport.authorId, selectedReport.title, 'processing')}
                            className={`flex-1 py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all ${selectedReport.status === 'processing' ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/30' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}
                          >
                            Processing
                          </button>
                          <button 
                            onClick={() => updateStatus(selectedReport.id, selectedReport.authorId, selectedReport.title, 'resolved')}
                            className={`flex-1 py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all ${selectedReport.status === 'resolved' ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}
                          >
                            Solved
                          </button>
                       </div>
                    </div>

                    {selectedReport.status === 'resolved' && (
                      <div className="mb-4">
                        <button 
                          onClick={() => setIsInvoiceModalOpen(true)}
                          className="w-full px-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-xl font-bold text-xs uppercase tracking-widest hover:shadow-lg hover:shadow-emerald-500/30 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2"
                        >
                          <FileText className="w-4 h-4" /> Download Final Invoice
                        </button>
                      </div>
                    )}

                    <div className="flex gap-3">
                      <button 
                        onClick={() => {
                          const newTitle = prompt('Edit Title:', selectedReport.title);
                          if (newTitle) {
                            updateDoc(doc(db, 'reports', selectedReport.id), { title: newTitle, updatedAt: serverTimestamp() });
                          }
                        }}
                        className="flex-1 px-4 py-3 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-blue-100 transition-colors flex items-center justify-center gap-2"
                      >
                        <Edit className="w-4 h-4" /> Edit
                      </button>

                      <button 
                        onClick={() => {
                          deleteReport(selectedReport.id);
                        }}
                        className="flex-1 px-4 py-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" /> Delete
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>

      <ConfirmDialog
        isOpen={showConfirmDelete}
        title="Delete Report"
        message="Are you sure you want to delete this report? This action cannot be undone."
        confirmText="Delete"
        cancelText="Cancel"
        isDestructive={true}
        isLoading={deleteLoading}
        onConfirm={confirmDelete}
        onCancel={() => {
          setShowConfirmDelete(false);
          setReportToDelete(null);
        }}
      />
      {selectedReport && (
        <InvoicePreviewModal
          isOpen={isInvoiceModalOpen}
          onClose={() => setIsInvoiceModalOpen(false)}
          report={selectedReport}
          authorName={authorProfile?.displayName || authorProfile?.email || 'Anonymous'}
        />
      )}
    </section>
  );
}
