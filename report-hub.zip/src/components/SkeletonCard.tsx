import React from 'react';
import { motion } from 'motion/react';

export default function SkeletonCard() {
  return (
    <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="glass-card p-4 sm:p-6 rounded-2xl sm:rounded-3xl flex flex-col justify-between animate-pulse"
    >
        <div className="aspect-[16/9] sm:aspect-video w-full bg-slate-200 dark:bg-slate-700/50 rounded-xl sm:rounded-2xl mb-4 sm:mb-6"></div>
        <div className="flex-1 flex flex-col">
            <div className="w-20 h-5 sm:h-6 bg-slate-200 dark:bg-slate-700/50 rounded-full mb-3 sm:mb-4"></div>
            <div className="w-3/4 h-6 sm:h-8 bg-slate-200 dark:bg-slate-700/50 rounded-lg mb-2"></div>
            <div className="w-full h-3 sm:h-4 bg-slate-200 dark:bg-slate-700/50 rounded-lg mb-2"></div>
            <div className="w-5/6 h-3 sm:h-4 bg-slate-200 dark:bg-slate-700/50 rounded-lg mb-4 sm:mb-6"></div>
            <div className="pt-3 sm:pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between mt-auto">
                <div className="w-20 sm:w-24 h-3 sm:h-4 bg-slate-200 dark:bg-slate-700/50 rounded-lg"></div>
                <div className="w-14 sm:w-16 h-6 sm:h-8 bg-slate-200 dark:bg-slate-700/50 rounded-full"></div>
            </div>
        </div>
    </motion.div>
  );
}
