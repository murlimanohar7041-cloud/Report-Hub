import { useState, useEffect } from 'react';
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthProvider';
import ReportCard from './ReportCard';
import SkeletonCard from './SkeletonCard';
import { motion, AnimatePresence } from 'motion/react';
import ReportDetailsModal from './ReportDetailsModal';
import { FileText, Clock, CheckCircle, List } from 'lucide-react';
import { playSound } from '../lib/sounds';

export default function UserDashboard() {
  const { user } = useAuth();
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState<any>(null);

  useEffect(() => {
    if (!user) return;
    
    // Play sound on dashboard open
    playSound('open');

    const q = query(
      collection(db, 'reports'),
      where('authorId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        timeAgo: doc.data().createdAt ? new Date(doc.data().createdAt.toDate()).toLocaleTimeString() : 'Just now'
      }));
      setReports(fetched);
      setLoading(false);
    });

    return unsubscribe;
  }, [user]);

  const stats = [
    { label: 'Total Reports', value: reports.length, icon: FileText, color: 'blue' },
    { label: 'Pending', value: reports.filter(r => r.status === 'open' || r.status === 'processing').length, icon: Clock, color: 'amber' },
    { label: 'Resolved', value: reports.filter(r => r.status === 'resolved').length, icon: CheckCircle, color: 'green' },
  ];

  if (!user) return <div className="text-center py-20">Please login to view your dashboard.</div>;

  return (
    <motion.section 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="py-12 sm:py-20 px-4 sm:px-6 lg:px-12 min-h-screen"
    >
      <div className="max-w-7xl mx-auto">
        <header className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h1 className="text-4xl md:text-5xl font-black tracking-tight uppercase text-gradient mb-4">Your Dashboard</h1>
            <p className="text-xl text-slate-500 dark:text-slate-400 font-medium">Tracking {user.displayName || 'your'} contributions to the community.</p>
          </div>
          
          <div className="flex gap-4">
            {stats.map((stat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="glass-card p-4 rounded-2xl flex items-center gap-3 min-w-[140px]"
              >
                <div className={`p-2 rounded-xl bg-${stat.color}-500/10 text-${stat.color}-600 dark:text-${stat.color}-400`}>
                  <stat.icon className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-black uppercase text-slate-400 tracking-wider">{stat.label}</div>
                  <div className="text-xl font-black text-slate-900 dark:text-white">{stat.value}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            Array(3).fill(0).map((_, i) => <SkeletonCard key={i} />)
          ) : (
            <>
              <AnimatePresence>
                {reports.map((report) => (
                  <ReportCard 
                    key={report.id} 
                    report={report} 
                    onClick={() => {
                        playSound('click');
                        setSelectedReport(report);
                    }} 
                  />
                ))}
              </AnimatePresence>
              {reports.length === 0 && (
                <div className="col-span-full py-20 text-center glass-card rounded-3xl">
                  <List className="w-16 h-16 text-slate-200 dark:text-slate-800 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-slate-500 mb-2">No Reports Yet</h3>
                  <p className="text-slate-400 mb-6">You haven't reported any problems yet. Be the first to help!</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <AnimatePresence>
        {selectedReport && (
          <ReportDetailsModal
            report={selectedReport}
            onClose={() => setSelectedReport(null)}
          />
        )}
      </AnimatePresence>
    </motion.section>
  );
}
