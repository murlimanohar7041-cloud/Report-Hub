import React, { useState } from 'react';
import { X, MapPin, Clock, ThumbsUp, Download, Edit, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { StatusBadge } from './StatusBadge';
import ReviewSection from './ReviewSection';
import { useAuth } from './AuthProvider';
import { doc, updateDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import ConfirmDialog from './ConfirmDialog';
import InvoicePreviewModal from './InvoicePreviewModal';
import { FileText } from 'lucide-react';
import { notify } from '../lib/notify';

interface ReportDetailsModalProps {
  report: any;
  onClose: () => void;
  onUpvote?: (id: string, authorId: string, currentCount: number) => void;
}

export default function ReportDetailsModal({ report, onClose, onUpvote }: ReportDetailsModalProps) {
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(report?.title || '');
  const [editDescription, setEditDescription] = useState(report?.description || '');
  const [loading, setLoading] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  
  const isAuthor = user?.uid === report?.authorId;

  const handleDownload = async () => {
    if (!report.imageUrl) return;
    try {
      const response = await fetch(report.imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `report-${report.id}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      console.error('Download failed', e);
    }
  };
  
  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthor && user?.role !== 'admin') return;
    setLoading(true);
    try {
      await updateDoc(doc(db, 'reports', report.id), {
        title: editTitle,
        description: editDescription,
        updatedAt: serverTimestamp()
      });
      report.title = editTitle;
      report.description = editDescription;
      setIsEditing(false);
      notify({ message: 'Report updated successfully', type: 'success' });
    } catch (error) {
      console.error('Error updating report', error);
      notify({ message: 'Failed to update report.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!isAuthor && user?.role !== 'admin') return;
    
    setShowConfirmDelete(true);
  };

  const confirmDelete = async () => {
    setDeleteLoading(true);
    try {
      await deleteDoc(doc(db, 'reports', report.id));
      setShowConfirmDelete(false);
      notify({ message: 'Report deleted successfully', type: 'success' });
      onClose();
    } catch (error) {
      console.error('Error deleting report', error);
      notify({ message: 'Failed to delete report.', type: 'error' });
      setDeleteLoading(false);
    }
  };

  if (!report) return null;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
    >
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" 
        onClick={onClose}
      ></div>
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white dark:bg-slate-900 w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-3xl shadow-2xl relative z-10 border border-slate-200 dark:border-slate-800"
      >
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 bg-slate-100/80 dark:bg-slate-800/80 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors z-20 backdrop-blur-sm"
        >
          <X className="w-5 h-5 text-slate-600 dark:text-slate-300" />
        </button>

        {report.imageUrl && (
          <div className="w-full h-48 sm:h-80 relative">
            <img 
              src={report.imageUrl} 
              alt={report.title} 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
            
            <button 
              onClick={handleDownload}
              className="absolute top-4 right-16 p-2 bg-slate-100/80 dark:bg-slate-800/80 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors z-20 backdrop-blur-sm"
              title="Download Image"
            >
              <Download className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            </button>

            <div className="absolute bottom-4 left-4 sm:left-6 flex items-center gap-2 sm:gap-3">
              <StatusBadge status={report.status} />
              <span className="text-white text-[10px] sm:text-xs font-bold uppercase tracking-wider bg-white/20 backdrop-blur-md px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-full">
                {report.category}
              </span>
            </div>
          </div>
        )}

        <div className="p-5 sm:p-10">
          {!report.imageUrl && (
            <div className="flex gap-2 sm:gap-3 mb-4 sm:mb-6">
               <StatusBadge status={report.status} />
               <span className="text-blue-600 dark:text-blue-400 text-[10px] sm:text-xs font-bold uppercase tracking-wider bg-blue-50 dark:bg-blue-900/30 px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-full">
                {report.category}
              </span>
            </div>
          )}
          
          <div className="flex justify-between items-start mb-2 sm:mb-4">
              <div className="flex-1">
                {isEditing ? (
                  <form onSubmit={handleEditSubmit} className="space-y-4">
                    <input 
                      type="text" 
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      className="w-full text-2xl sm:text-4xl font-black text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-800 border-2 border-blue-500 rounded-xl px-4 py-2 outline-none"
                      placeholder="Title"
                      required
                    />
                    <textarea 
                      value={editDescription}
                      onChange={(e) => setEditDescription(e.target.value)}
                      className="w-full text-slate-600 dark:text-slate-300 text-sm sm:text-lg leading-relaxed bg-slate-50 dark:bg-slate-800 border-2 border-blue-500 rounded-xl px-4 py-3 min-h-[120px] outline-none resize-y"
                      placeholder="Description"
                      required
                    />
                    <div className="flex items-center gap-3">
                        <button type="submit" disabled={loading} className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors disabled:opacity-50">Save</button>
                        <button type="button" onClick={() => setIsEditing(false)} className="px-6 py-2 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors">Cancel</button>
                    </div>
                  </form>
                ) : (
                  <>
                    <h2 className="text-2xl sm:text-4xl font-black text-slate-900 dark:text-white leading-tight mb-2 sm:mb-4">
                      {report.title}
                    </h2>
                    <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-lg leading-relaxed mb-6 sm:mb-8">
                      {report.description}
                    </p>
                  </>
                )}
              </div>

              {!isEditing && (isAuthor || user?.role === 'admin') && (
                  <div className="flex items-center gap-2 ml-4">
                      <button onClick={() => setIsEditing(true)} className="p-2 text-slate-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-full transition-colors" title="Edit Report">
                          <Edit className="w-5 h-5" />
                      </button>
                      <button onClick={handleDelete} className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors" title="Delete Report">
                          <Trash2 className="w-5 h-5" />
                      </button>
                  </div>
              )}
          </div>

          <div className="flex flex-wrap items-center gap-4 sm:gap-6 py-4 sm:py-6 border-y border-slate-100 dark:border-slate-800">
            {report.location && (
              <div className="flex items-center gap-1.5 sm:gap-2 text-slate-500 dark:text-slate-400">
                <MapPin className="w-4 h-4 sm:w-5 sm:h-5 text-blue-500" />
                <span className="font-medium text-xs sm:text-sm">
                  {report.location.lat.toFixed(4)}, {report.location.lng.toFixed(4)}
                </span>
              </div>
            )}
            <div className="flex items-center gap-1.5 sm:gap-2 text-slate-500 dark:text-slate-400">
              <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-purple-500" />
              <span className="font-medium text-xs sm:text-sm">{report.timeAgo || 'Recently'}</span>
            </div>
            
            <div className="flex flex-col sm:flex-row items-center gap-3 ml-auto w-full sm:w-auto mt-2 sm:mt-0">
              {report.status === 'resolved' && (
                  <button 
                  onClick={() => setIsInvoiceModalOpen(true)}
                  className="flex items-center justify-center w-full sm:w-auto gap-2 text-sm font-bold text-teal-600 dark:text-teal-400 hover:text-emerald-700 dark:hover:text-emerald-300 transition-colors bg-teal-50 dark:bg-emerald-900/20 px-5 py-2.5 rounded-full border border-teal-200 dark:border-teal-800 hover:-translate-y-0.5"
                  >
                  <FileText className="w-4 h-4" />
                  <span>Preview Invoice</span>
                  </button>
              )}
              {onUpvote && (
                  <button 
                  onClick={() => onUpvote(report.id, report.authorId, report.upvoteCount)}
                  className="flex items-center justify-center w-full sm:w-auto gap-2 text-sm font-bold text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors bg-slate-100 dark:bg-slate-800 px-5 py-2.5 rounded-full"
                  >
                  <ThumbsUp className="w-4 h-4" />
                  <span>{report.upvoteCount || 0} Upvotes</span>
                  </button>
              )}
            </div>
          </div>

          <ReviewSection reportId={report.id} isResolved={report.status === 'resolved'} />

        </div>
      </motion.div>

      <ConfirmDialog
        isOpen={showConfirmDelete}
        title="Delete Report"
        message="Are you sure you want to delete this report? This action cannot be undone."
        confirmText="Delete"
        cancelText="Cancel"
        isDestructive={true}
        isLoading={deleteLoading}
        onConfirm={confirmDelete}
        onCancel={() => setShowConfirmDelete(false)}
      />
      <InvoicePreviewModal
        isOpen={isInvoiceModalOpen}
        onClose={() => setIsInvoiceModalOpen(false)}
        report={report}
        authorName="Report Hub User"
      />
    </motion.div>
  );
}
