import { FileSearch } from 'lucide-react';
import { motion } from 'motion/react';

export default function LottieEmpty({ message = "No data found." }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center col-span-full">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <FileSearch className="w-24 h-24 text-slate-300 dark:text-slate-600 mb-4" />
      </motion.div>
      <p className="text-lg font-medium text-slate-500 mt-4">{message}</p>
    </div>
  );
}
