import { MapPin, Menu, X, UserCircle, LogOut, Shield, Moon, Sun, BarChart3, Globe2, Languages, Bell, FileText, Home, LayoutDashboard } from 'lucide-react';
import { useAuth } from './AuthProvider';
import { useTheme } from './ThemeProvider';
import { useTranslation } from 'react-i18next';
import { useState, useEffect, useRef } from 'react';
import { collection, query, orderBy, onSnapshot, limit, where, updateDoc, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import LoginModal from './LoginModal';
import { playSound } from '../lib/sounds';

interface HeaderProps {
  onReportClick?: () => void;
  onHomeClick?: () => void;
  onAllReportsClick?: () => void;
  onAdminClick?: () => void;
  onAnalyticsClick?: () => void;
  onMapClick?: () => void;
  onDashboardClick?: () => void;
  onAboutClick?: () => void;
}

export default function Header({ onReportClick, onHomeClick, onAllReportsClick, onAdminClick, onAnalyticsClick, onMapClick, onDashboardClick, onAboutClick }: HeaderProps) {
  const { user, logOut } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { t, i18n } = useTranslation();
  const [unreadCount, setUnreadCount] = useState(0);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const prevUnreadCount = useRef(-1);

  const toggleLanguage = () => {
    const newLang = i18n.language === 'en' ? 'hi' : 'en';
    i18n.changeLanguage(newLang);
  };

  useEffect(() => {
    if (!user) {
      setUnreadCount(0);
      setNotifications([]);
      prevUnreadCount.current = 0;
      return;
    }

    const q = query(
      collection(db, 'notifications'), 
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc'), 
      limit(5)
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) }));
      setNotifications(fetched);
      const newUnread = fetched.filter((n: any) => !n.read).length;
      
      if (newUnread > prevUnreadCount.current && prevUnreadCount.current >= 0) {
        // Only play if it's not the initial load where prevUnreadCount is just starting?
        // Actually, playing sound on load if you have unread notifications might be annoying.
        // Let's set it to -1 initially.
        if (prevUnreadCount.current !== -1) {
           playSound('notify');
        }
      }
      setUnreadCount(newUnread);
      prevUnreadCount.current = newUnread;
    });
    return unsubscribe;
  }, [user]);

  const markAllAsRead = async () => {
    if (!user) return;
    const unread = notifications.filter(n => !n.read);
    for (const notification of unread) {
        await updateDoc(doc(db, 'notifications', notification.id), { read: true });
    }
  };

  const handleAllReportsClick = () => {
    setIsNotificationsOpen(false);
    if (onAllReportsClick) onAllReportsClick();
    setIsMobileMenuOpen(false);
  };

  const navItemClass = "text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all rounded-full px-4 py-2 flex items-center gap-2 w-full lg:w-auto";
  const iconButtonClass = "p-2.5 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-full transition-all relative";

  return (
    <>
    <header className="sticky top-0 z-50 w-full glass border-b border-slate-200/50 dark:border-slate-800/50 backdrop-blur-xl bg-white/80 dark:bg-slate-950/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 py-3">
        <div className="flex justify-between items-center relative z-20">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => { setIsMobileMenuOpen(false); onHomeClick?.(); }}>
            <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-2.5 rounded-2xl shadow-lg shadow-blue-500/20 group-hover:shadow-blue-500/40 group-hover:-translate-y-0.5 transition-all shrink-0">
              <MapPin className="h-5 w-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl sm:text-2xl font-black tracking-tighter uppercase text-slate-900 dark:text-white group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-purple-600 transition-all leading-tight">Report Hub</span>
              <span className="text-[9px] sm:text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-[0.2em] -mt-0.5">Government of India</span>
            </div>
          </div>
          
          <nav className="hidden lg:flex items-center gap-1 lg:gap-2">
            <button onClick={handleAllReportsClick} className={navItemClass}>{t('All Reports')}</button>
            <button onClick={onMapClick} className={navItemClass}>{t('Map')}</button>
            <button onClick={onAnalyticsClick} className={navItemClass}>{t('Analytics')}</button>
            <button onClick={onAboutClick} className={navItemClass}>About</button>
            
            {user && (
               <button onClick={onDashboardClick} className={navItemClass}>Dashboard</button>
            )}
            
            {user?.role === 'admin' && (
              <button onClick={onAdminClick} className={`${navItemClass} text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/20`}>
                <Shield className="w-4 h-4" /> Admin
              </button>
            )}
            
            <div className="flex items-center gap-1 border-l border-slate-200 dark:border-slate-800 pl-4 ml-2 relative">
              <div className="relative">
                <button 
                  onClick={() => {
                    setIsNotificationsOpen(!isNotificationsOpen);
                    if (!isNotificationsOpen) markAllAsRead();
                  }} 
                  className={iconButtonClass}
                  title="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-slate-900 animate-pulse"></span>
                  )}
                </button>

                <AnimatePresence>
                  {isNotificationsOpen && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute top-full right-0 mt-3 w-80 bg-white dark:bg-slate-900 rounded-3xl shadow-2xl shadow-blue-900/5 border border-slate-100 dark:border-slate-800 overflow-hidden z-50"
                    >
                        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-800/50">
                            <span className="font-black uppercase text-[10px] tracking-widest text-slate-500">Notifications</span>
                            {unreadCount > 0 && <span className="text-[10px] bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400 px-2 py-0.5 rounded-full font-bold shadow-sm">{unreadCount} New</span>}
                        </div>
                        <div className="max-h-80 overflow-y-auto">
                            {notifications.length === 0 ? (
                                <div className="p-8 text-center text-sm font-medium text-slate-400">No notifications yet.</div>
                            ) : (
                                notifications.map((n) => (
                                    <div key={n.id} className={`p-4 border-b border-slate-50 dark:border-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors ${!n.read ? 'bg-blue-50/50 dark:bg-blue-900/10' : ''}`}>
                                        {n.newStatus === 'notification' ? (
                                            <p className="text-sm text-slate-700 dark:text-slate-300 font-medium">
                                                {n.reportTitle}
                                            </p>
                                        ) : (
                                            <p className="text-sm text-slate-700 dark:text-slate-300">
                                                Status of <span className="font-bold">"{n.reportTitle}"</span> updated to <span className="text-blue-600 dark:text-blue-400 font-bold uppercase text-[10px] bg-blue-50 dark:bg-blue-900/30 px-1.5 py-0.5 rounded">{n.newStatus}</span>
                                            </p>
                                        )}
                                    </div>
                                ))
                            )}
                        </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <button onClick={toggleLanguage} className={iconButtonClass} title="Toggle Language">
                <Languages className="w-5 h-5" />
              </button>
              <button onClick={toggleTheme} className={iconButtonClass} title="Toggle Theme">
                {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>

              {user ? (
                 <button onClick={logOut} className={`${iconButtonClass} text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 ml-2`} title="Logout">
                   <LogOut className="w-5 h-5" />
                 </button>
              ) : (
                 <button 
                  onClick={() => setIsLoginModalOpen(true)} 
                  className="ml-3 px-5 py-2.5 hover:-translate-y-0.5 transition-all flex items-center gap-2 font-bold rounded-full bg-slate-100 text-slate-800 border border-slate-200 dark:bg-slate-800 dark:text-white dark:border-slate-700 shadow-sm hover:shadow-md hover:bg-white dark:hover:bg-slate-700"
                 >
                   <UserCircle className="w-5 h-5" /> {t('Login')}
                 </button>
              )}

              <button 
                onClick={() => {
                    if (!user) {
                        setIsLoginModalOpen(true);
                    } else if (onReportClick) {
                        onReportClick();
                    }
                }}
                className="ml-3 px-6 py-2.5 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-bold shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50 hover:-translate-y-0.5 transition-all duration-300 whitespace-nowrap flex items-center gap-2"
              >
                <MapPin className="w-4 h-4" />
                {t('Report Issue')}
              </button>
            </div>
          </nav>

          {/* Mobile Actions */}
          <div className="flex lg:hidden items-center gap-2">
            <div className="relative">
              <button 
                onClick={() => {
                  setIsNotificationsOpen(!isNotificationsOpen);
                  if (!isNotificationsOpen) markAllAsRead();
                }} 
                className="relative p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-slate-900 animate-pulse"></span>
                )}
              </button>

              <AnimatePresence>
                  {isNotificationsOpen && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute top-full right-[-40px] mt-3 w-80 bg-white dark:bg-slate-900 rounded-3xl shadow-2xl shadow-blue-900/5 border border-slate-100 dark:border-slate-800 overflow-hidden z-50 max-w-[calc(100vw-32px)]"
                    >
                        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-800/50">
                            <span className="font-black uppercase text-[10px] tracking-widest text-slate-500">Notifications</span>
                            {unreadCount > 0 && <span className="text-[10px] bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400 px-2 py-0.5 rounded-full font-bold shadow-sm">{unreadCount} New</span>}
                        </div>
                        <div className="max-h-80 overflow-y-auto">
                            {notifications.length === 0 ? (
                                <div className="p-8 text-center text-sm font-medium text-slate-400">No notifications yet.</div>
                            ) : (
                                notifications.map((n) => (
                                    <div key={n.id} className={`p-4 border-b border-slate-50 dark:border-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors ${!n.read ? 'bg-blue-50/50 dark:bg-blue-900/10' : ''}`}>
                                        {n.newStatus === 'notification' ? (
                                            <p className="text-sm text-slate-700 dark:text-slate-300 font-medium">
                                                {n.reportTitle}
                                            </p>
                                        ) : (
                                            <p className="text-sm text-slate-700 dark:text-slate-300">
                                                Status of <span className="font-bold">"{n.reportTitle}"</span> updated to <span className="text-blue-600 dark:text-blue-400 font-bold uppercase text-[10px] bg-blue-50 dark:bg-blue-900/30 px-1.5 py-0.5 rounded">{n.newStatus}</span>
                                            </p>
                                        )}
                                    </div>
                                ))
                            )}
                        </div>
                    </motion.div>
                  )}
              </AnimatePresence>
            </div>
            
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
              className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden absolute top-full left-0 w-full bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden z-10"
          >
            <div className="flex flex-col p-4 space-y-4">
              <button onClick={() => { setIsMobileMenuOpen(false); onHomeClick?.(); }} className={navItemClass}>
                <Home className="w-5 h-5"/> {t('Home')}
              </button>
              <button onClick={handleAllReportsClick} className={navItemClass}>
                <FileText className="w-5 h-5"/> {t('All Reports')}
              </button>
              <button onClick={() => { setIsMobileMenuOpen(false); onMapClick?.(); }} className={navItemClass}>
                <Globe2 className="w-5 h-5"/> {t('Map')}
              </button>
              
              {user && (
                <button onClick={() => { setIsMobileMenuOpen(false); onDashboardClick?.(); }} className={navItemClass}>
                  <LayoutDashboard className="w-5 h-5"/> Dashboard
                </button>
              )}

              <button onClick={() => { setIsMobileMenuOpen(false); onAnalyticsClick?.(); }} className={navItemClass}>
                <BarChart3 className="w-5 h-5"/> {t('Analytics')}
              </button>
              <button onClick={() => { setIsMobileMenuOpen(false); onAboutClick?.(); }} className={navItemClass}>
                <Globe2 className="w-5 h-5"/> About
              </button>
              
              {user?.role === 'admin' && (
                <button onClick={() => { setIsMobileMenuOpen(false); onAdminClick?.(); }} className="font-medium text-purple-600 dark:text-purple-400 hover:text-purple-800 transition-colors flex items-center gap-2 py-2">
                  <Shield className="w-5 h-5" /> {t('Admin Dashboard')}
                </button>
              )}
              
              <div className="border-t border-slate-200 dark:border-slate-800 pt-4 flex flex-col gap-4">
                <div className="flex flex-wrap items-center gap-2">
                  <button onClick={toggleLanguage} className="flex-1 flex items-center justify-center gap-2 p-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-medium">
                    <Languages className="w-5 h-5" /> Language
                  </button>
                  <button onClick={toggleTheme} className="flex-1 flex items-center justify-center gap-2 p-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-medium">
                    {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />} Theme
                  </button>
                </div>

                {user ? (
                   <button onClick={() => { setIsMobileMenuOpen(false); logOut(); }} className="w-full flex items-center justify-center gap-2 p-3 text-red-600 dark:text-red-400 font-bold bg-red-50 dark:bg-red-900/20 rounded-xl hover:bg-red-100 transition-colors">
                     <LogOut className="w-5 h-5" /> Logout
                   </button>
                ) : (
                   <button onClick={() => { setIsMobileMenuOpen(false); setIsLoginModalOpen(true); }} className="w-full flex items-center justify-center gap-2 p-3.5 text-slate-800 dark:text-white font-bold bg-slate-100 border border-slate-200 dark:bg-slate-800 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-700 rounded-xl shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all">
                     <UserCircle className="w-5 h-5" /> {t('Login')}
                   </button>
                )}

                <button 
                  onClick={() => { 
                      setIsMobileMenuOpen(false); 
                      if (!user) {
                          setIsLoginModalOpen(true);
                      } else if (onReportClick) {
                          onReportClick(); 
                      }
                  }}
                  className="w-full px-6 py-3.5 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-bold shadow-lg shadow-blue-500/30 flex items-center justify-center"
                >
                  {t('Report Issue')}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
    <LoginModal isOpen={isLoginModalOpen} onClose={() => setIsLoginModalOpen(false)} />
    </>
  );
}
