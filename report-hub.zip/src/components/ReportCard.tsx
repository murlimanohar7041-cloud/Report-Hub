import React from 'react';
import { StatusBadge } from './StatusBadge';
import { ThumbsUp, Clock, Star, MessageSquare } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from './AuthProvider';

interface ReportCardProps {
  report: any;
  onClick: () => void;
  onUpvote?: (id: string, authorId: string, currentCount: number) => void;
  key?: React.Key;
}

export default function ReportCard({ report, onClick, onUpvote }: ReportCardProps) {

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.3 }}
      className="group glass-card p-4 sm:p-6 rounded-2xl sm:rounded-3xl flex flex-col justify-between cursor-pointer"
      onClick={onClick}
    >
      {report.imageUrl && (
        <div className="aspect-[16/9] sm:aspect-video w-full overflow-hidden bg-slate-100 dark:bg-slate-800 relative rounded-xl sm:rounded-2xl mb-4 sm:mb-6">
          <img 
            src={report.imageUrl} 
            alt={report.title} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute top-2 right-2 sm:top-3 sm:right-3 shadow-md rounded-full bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm">
            <StatusBadge status={report.status} />
          </div>
        </div>
      )}
      
      <div className="flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-3 sm:mb-4">
          <span className="text-blue-600 dark:text-blue-400 text-[9px] sm:text-[10px] font-black uppercase tracking-wider bg-blue-50 dark:bg-blue-900/30 px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-full">
            {report.category}
          </span>
          {!report.imageUrl && <div className="absolute top-4 right-4 sm:top-6 sm:right-6"><StatusBadge status={report.status} /></div>}
        </div>
        
        <h3 className="text-lg sm:text-2xl font-bold leading-tight mb-2 text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
          {report.title}
        </h3>
        
        <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm mb-4 sm:mb-6 line-clamp-2">
          {report.description}
        </p>

        {/* Rating Display */}
        {(report.averageRating > 0) && (
            <div className="flex items-center gap-1 mb-3 sm:mb-4">
                <Star className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-500 fill-amber-500" />
                <span className="text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300">
                    {report.averageRating.toFixed(1)}
                </span>
                <span className="text-[10px] sm:text-xs text-slate-500">
                    ({report.reviewCount} {report.reviewCount === 1 ? 'review' : 'reviews'})
                </span>
            </div>
        )}
        
        <div className="pt-3 sm:pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between mt-auto gap-2">
          <span className="text-[10px] sm:text-xs font-bold text-slate-400 dark:text-slate-500 flex items-center gap-1">
            <Clock className="w-3 h-3" /> {report.timeAgo || 'Recently'}
          </span>
          
          <div className="flex gap-2">
            {(report.reviewCount > 0) && (
                <div className="flex items-center gap-1.5 text-[10px] sm:text-xs font-bold text-slate-500 bg-slate-50 dark:bg-slate-800/50 px-2.5 py-1.5 sm:px-3 sm:py-2 rounded-full border border-slate-200 dark:border-slate-700">
                    <MessageSquare className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                    <span>{report.reviewCount}</span>
                </div>
            )}
            {onUpvote && (
                <button 
                onClick={(e) => { e.stopPropagation(); onUpvote(report.id, report.authorId, report.upvoteCount); }}
                className="flex items-center gap-1.5 text-[10px] sm:text-xs font-bold text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 transition-colors bg-slate-50 dark:bg-slate-800/50 px-3 py-1.5 sm:px-4 sm:py-2 rounded-full border border-slate-200 dark:border-slate-700"
                >
                <ThumbsUp className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                <span>{report.upvoteCount || 0}</span>
                </button>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
