
import React from 'react';
import { motion } from 'motion/react';
import { MapPin, Shield, Users, BarChart3, Globe2, Heart, Award, Info } from 'lucide-react';

export default function About() {
  const features = [
    {
      icon: <MapPin className="w-6 h-6 text-blue-500" />,
      title: "Geographical Tracking",
      description: "Precisely mark the location of community issues on an interactive map for faster identification."
    },
    {
      icon: <Shield className="w-6 h-6 text-purple-500" />,
      title: "Resolution Verified",
      description: "Every report is tracked until its resolution, ensuring accountability and transparency."
    },
    {
      icon: <Users className="w-6 h-6 text-emerald-500" />,
      title: "Community Driven",
      description: "Empowering citizens to take active part in improving their local neighborhoods."
    },
    {
      icon: <BarChart3 className="w-6 h-6 text-orange-500" />,
      title: "Live Analytics",
      description: "View real-time statistics and trends of resolved issues across the city."
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-20"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 font-bold text-xs uppercase tracking-widest mb-6">
            <Info className="w-4 h-4" /> About Report Hub
          </div>
          <h1 className="text-4xl md:text-6xl font-black text-slate-900 dark:text-white uppercase tracking-tighter mb-6">
            Building a Better <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Community Together</span>
          </h1>
          <p className="max-w-2xl mx-auto text-lg text-slate-600 dark:text-slate-400 font-medium leading-relaxed">
            Report Hub is a citizen-first platform designed to bridge the gap between residents and city administration. 
            Report local issues like potholes, streetlights, or waste, and watch them get resolved.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {features.map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 hover:shadow-2xl hover:shadow-blue-500/10 transition-all group"
            >
              <div className="w-14 h-14 rounded-2xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold dark:text-white mb-3 tracking-tight">{feature.title}</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <h2 className="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Our Mission</h2>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="mt-1 w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center shrink-0">
                  <div className="w-2 h-2 rounded-full bg-blue-600"></div>
                </div>
                <div>
                  <h4 className="font-bold dark:text-white">Transparency</h4>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">Real-time status updates for every reported issue ensures you're always in the loop.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="mt-1 w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center shrink-0">
                  <div className="w-2 h-2 rounded-full bg-purple-600"></div>
                </div>
                <div>
                  <h4 className="font-bold dark:text-white">Efficiency</h4>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">Direct communication with responsible departments reduces turnaround time for repairs.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="mt-1 w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center shrink-0">
                  <div className="w-2 h-2 rounded-full bg-emerald-600"></div>
                </div>
                <div>
                  <h4 className="font-bold dark:text-white">Recognition</h4>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">Top reporters are highlighted for their contribution to maintaining city infrastructure.</p>
                </div>
              </div>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-[3rem] p-12 text-white relative overflow-hidden"
          >
            <div className="relative z-10">
              <h3 className="text-3xl font-bold mb-6">Designed & Developed for You</h3>
              <p className="opacity-90 leading-relaxed mb-8">
                Report Hub is built with modern technologies to ensure a fast, secure, and reliable experience for all citizens.
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center">
                  <Heart className="w-6 h-6 fill-white" />
                </div>
                <div>
                  <p className="font-bold">Murli Manohar kumar</p>
                  <p className="text-sm opacity-70">Lead Architect & Developer</p>
                </div>
              </div>
            </div>
            <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-white/10 rounded-full blur-3xl"></div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-slate-800 p-12 text-center"
        >
          <Award className="w-16 h-16 text-yellow-500 mx-auto mb-6" />
          <h2 className="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight mb-4">A Note on Security</h2>
          <p className="max-w-3xl mx-auto text-slate-600 dark:text-slate-400 mb-8 leading-relaxed font-medium">
            We take your data seriously. All reports and user profiles are secured with modern encryption and follow 
            strict security guidelines to protect citizen privacy while ensuring community transparency.
          </p>
          <div className="flex flex-wrap justify-center gap-8">
             <div className="flex flex-col items-center">
                <span className="text-3xl font-black text-blue-600">100%</span>
                <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Secure</span>
             </div>
             <div className="flex flex-col items-center">
                <span className="text-3xl font-black text-purple-600">Secure</span>
                <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Database</span>
             </div>
             <div className="flex flex-col items-center">
                <span className="text-3xl font-black text-emerald-600">Live</span>
                <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Integration</span>
             </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
