export function StatusBadge({ status }: { status: string }) {
  if (status === 'resolved') {
    return (
      <span className="px-3 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase tracking-wider rounded-full shadow-sm">
        Solved
      </span>
    );
  }
  if (status === 'processing') {
    return (
      <span className="px-3 py-1 bg-amber-100 text-amber-700 text-[10px] font-black uppercase tracking-wider rounded-full shadow-sm">
        Processing
      </span>
    );
  }
  return (
    <span className="px-3 py-1 bg-indigo-100 text-indigo-700 text-[10px] font-black uppercase tracking-wider rounded-full shadow-sm">
      Pending
    </span>
  );
}
