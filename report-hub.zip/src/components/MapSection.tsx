import { useState, useEffect } from 'react';
import { collection, query, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { StatusBadge } from './StatusBadge';
import ReportDetailsModal from './ReportDetailsModal';

// Fix for default marker icon in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

export default function MapSection() {
  const [reports, setReports] = useState<any[]>([]);
  const [selectedReport, setSelectedReport] = useState<any>(null);

  useEffect(() => {
    const fetchReports = async () => {
      try {
        // Fetch reports that have location
        const q = query(collection(db, 'reports'));
        const snapshot = await getDocs(q);
        const data = snapshot.docs
            .map(doc => ({ id: doc.id, ...doc.data() }))
            .filter((r: any) => r.location && r.location.lat && r.location.lng);
        setReports(data);
      } catch (error) {
        console.error("Error fetching map reports", error);
      }
    };
    fetchReports();
  }, []);

  const defaultCenter: [number, number] = [20.5937, 78.9629]; // India Center

  return (
    <section className="py-20 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="mb-12">
          <h2 className="text-3xl font-black tracking-tight uppercase text-gradient mb-2">Community Reports Map</h2>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Explore issues reported in your area.</p>
        </div>

        <div className="h-[500px] w-full rounded-3xl overflow-hidden shadow-xl border border-slate-200 dark:border-slate-800 relative z-0">
          <MapContainer 
            center={defaultCenter} 
            zoom={5} 
            scrollWheelZoom={false}
            className="w-full h-full"
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {reports.map((report) => (
              <Marker 
                key={report.id} 
                position={[report.location.lat, report.location.lng]}
              >
                <Popup className="rounded-xl overflow-hidden">
                    <div className="p-1 min-w-[200px]">
                        <div className="font-bold text-sm mb-1 line-clamp-1">{report.title}</div>
                        <div className="mb-2">
                             <StatusBadge status={report.status} />
                        </div>
                        <button 
                            onClick={() => setSelectedReport(report)}
                            className="text-xs w-full bg-blue-600 text-white rounded bg-blue-600 hover:bg-blue-700 py-1.5 transition-colors font-bold"
                        >
                            View Details
                        </button>
                    </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>
      </div>
      
      {selectedReport && (
        <ReportDetailsModal
          report={selectedReport}
          onClose={() => setSelectedReport(null)}
        />
      )}
    </section>
  );
}
