import { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import ReportCard from './ReportCard';
import SkeletonCard from './SkeletonCard';
import ReportDetailsModal from './ReportDetailsModal';

export default function TopRatedReports() {
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState<any>(null);

  useEffect(() => {
    const fetchTopRated = async () => {
      try {
        const q = query(
            collection(db, 'reports'), 
            orderBy('averageRating', 'desc'),
            limit(3)
        );
        const snapshot = await getDocs(q);
        const fetched = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          timeAgo: doc.data().createdAt ? new Date(doc.data().createdAt.toDate()).toLocaleDateString() : 'Just now'
        })).filter((r: any) => r.averageRating && r.averageRating > 0); // Only reports with ratings
        setReports(fetched);
      } catch (error) {
        console.error("Error fetching top rated", error);
      } finally {
        setLoading(false);
      }
    };
    fetchTopRated();
  }, []);

  if (!loading && reports.length === 0) return null;

  return (
    <section className="py-12 sm:py-20 relative z-10 bg-slate-50/50 dark:bg-slate-900/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="mb-8 sm:mb-12">
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight uppercase text-gradient mb-2">Top Rated Solutions</h2>
          <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 font-medium">The best community fixes as voted by you.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {loading ? (
             Array(3).fill(0).map((_, i) => <SkeletonCard key={i} />)
          ) : (
            reports.map((report) => (
              <ReportCard 
                key={report.id} 
                report={report} 
                onClick={() => setSelectedReport(report)} 
                onUpvote={() => {}} // Top rated shouldn't need upvoting as much, but we could add it
              />
            ))
          )}
        </div>
      </div>
      
      {selectedReport && (
        <ReportDetailsModal
          report={selectedReport}
          onClose={() => setSelectedReport(null)}
        />
      )}
    </section>
  );
}
