import { CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';

export default function LottieSuccess({ message = "Success!" }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center h-full min-h-[300px]">
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 20 }}
      >
        <CheckCircle className="w-32 h-32 text-green-500 mb-4" />
      </motion.div>
      <h3 className="text-2xl font-black text-slate-800 dark:text-white mt-4">{message}</h3>
    </div>
  );
}
