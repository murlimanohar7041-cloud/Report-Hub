import React, { useState, useRef, useCallback } from 'react';
import { Upload, X, AlertCircle, MapPin, Sparkles, Loader2 } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { useAuth } from './AuthProvider';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import LottieSuccess from './LottieSuccess';
import { playSound } from '../lib/sounds';

import { notify } from '../lib/notify';

export default function ReportForm({ onCancel }: { onCancel?: () => void }) {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    image: null as File | null,
    location: null as { lat: number, lng: number } | null
  });
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isCategorizing, setIsCategorizing] = useState(false);
  const [locationStatus, setLocationStatus] = useState<string>('Click to get location');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.title.trim() || formData.title.length < 3) newErrors.title = 'Title must be at least 3 characters';
    if (!formData.description.trim()) newErrors.description = 'Description is required';
    if (!formData.category) newErrors.category = 'Category is required';
    if (!formData.location) newErrors.location = 'Location is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const getLocation = () => {
    setLocationStatus('Locating...');
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData({
            ...formData,
            location: {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            }
          });
          setLocationStatus('Location acquired ✓');
          setErrors(prev => ({ ...prev, location: '' }));
        },
        (error) => {
          setLocationStatus('Failed to get location. Ensure permissions are granted.');
        }
      );
    } else {
      setLocationStatus('Geolocation is not supported by your browser.');
    }
  };

  const autoCategorize = async () => {
    if (!formData.description) return;
    setIsCategorizing(true);
    try {
      const res = await fetch('/api/categorize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description: formData.description })
      });
      if (res.ok) {
        const { category } = await res.json();
        setFormData(prev => ({ ...prev, category }));
        setErrors(prev => ({ ...prev, category: '' }));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsCategorizing(false);
    }
  };

  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 800;
          const MAX_HEIGHT = 800;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          // 0.7 quality for good balance of size and quality
          const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
          resolve(dataUrl);
        };
        img.onerror = (e) => reject(e);
      };
      reader.onerror = (e) => reject(e);
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      notify({ message: "You must be logged in to report.", type: 'error' });
      return;
    }

    if (validate()) {
      setIsSubmitting(true);
      try {
        let imageUrl = null;
        if (formData.image) {
          try {
            imageUrl = await compressImage(formData.image);
          } catch (uploadError) {
            console.error("Image compression failed", uploadError);
            // Non-blocking, continue without image or throw?
            // Let's continue without image if it fails, or alert.
          }
        }

        const reportData = {
          title: formData.title,
          description: formData.description,
          category: formData.category,
          location: formData.location || null,
          imageUrl: imageUrl || null,
          status: 'open',
          authorId: user.uid,
          upvoteCount: 0,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        };

        await addDoc(collection(db, 'reports'), reportData);

        // Show success animation and notify
        playSound('submit');
        notify({ 
          message: "Report Submitted Successfully!", 
          type: 'success', 
          saveToDb: true, 
          userId: user.uid 
        });

        setIsSuccess(true);
        setTimeout(() => {
            if (onCancel) onCancel();
        }, 3000); // Close modal automatically after 3s

      } catch (error) {
        console.error("Error submitting report", error);
        notify({ message: "Failed to submit report. Please check your internet connection.", type: 'error' });
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const handleFile = (file: File) => {
    setFormData({ ...formData, image: file });
    const reader = new FileReader();
    reader.onloadend = () => {
        setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setIsDragging(true);
    } else if (e.type === 'dragleave') {
      setIsDragging(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  }, [formData]);

  if (isSuccess) {
      return (
        <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center p-12 glass-card rounded-3xl max-w-lg mx-auto"
        >
            <LottieSuccess message="Report Submitted!" />
            <p className="text-slate-500 mt-2 text-center text-sm">Thank you for reporting this issue. Your efforts help make the community better.</p>
        </motion.div>
      );
  }

  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="py-12 sm:py-20 px-4 sm:px-6 lg:px-12 relative z-10"
    >
      <div className="max-w-3xl mx-auto">
        <div className="mb-10 text-center">
            <h2 className="text-4xl md:text-5xl font-black tracking-tight uppercase mb-4 text-gradient">Report an Issue</h2>
            <p className="text-xl text-slate-500 dark:text-slate-400 font-medium">Help us keep the city safe by providing details about the problem.</p>
        </div>

        <form onSubmit={handleSubmit} className="glass-card p-8 md:p-10 rounded-3xl flex flex-col gap-8 relative overflow-hidden">
          
          <div className="absolute top-0 right-0 p-8 opacity-5 dark:opacity-10 pointer-events-none">
             <AlertCircle className="w-64 h-64 text-blue-600" />
          </div>

          <div className="relative z-10">
            <label htmlFor="title" className="block text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
              Problem Title
            </label>
            <input
              type="text"
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g. Broken Streetlight on 5th Ave"
              className={`w-full px-5 py-4 rounded-2xl border ${errors.title ? 'border-red-500 focus:ring-red-500' : 'border-slate-200 dark:border-slate-700/50 focus:ring-blue-600 focus:border-blue-600'} bg-white/70 dark:bg-slate-900/50 backdrop-blur-md transition-all outline-none focus:ring-2`}
            />
            {errors.title && (
                <p className="mt-2 text-sm text-red-500 font-bold flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" /> {errors.title}
                </p>
            )}
          </div>

          {/* Description */}
          <div className="relative z-10">
            <div className="flex justify-between items-end mb-2">
              <label htmlFor="description" className="block text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Description
              </label>
              <button 
                type="button" 
                onClick={autoCategorize}
                disabled={!formData.description || isCategorizing}
                className="text-xs font-bold text-purple-600 hover:text-purple-700 dark:text-purple-400 dark:hover:text-purple-300 flex items-center gap-1 disabled:opacity-50 transition-colors"
                title="AI will auto-suggest category based on description"
              >
                {isCategorizing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />} 
                Auto Tag
              </button>
            </div>
            <textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Please provide more details about the location and nature of the problem..."
              rows={5}
              className={`w-full px-5 py-4 rounded-2xl border ${errors.description ? 'border-red-500 focus:ring-red-500' : 'border-slate-200 dark:border-slate-700/50 focus:ring-blue-600 focus:border-blue-600'} bg-white/70 dark:bg-slate-900/50 backdrop-blur-md transition-all outline-none focus:ring-2 resize-y`}
            />
             {errors.description && (
                <p className="mt-2 text-sm text-red-500 font-bold flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" /> {errors.description}
                </p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
            {/* Category */}
            <div>
              <label htmlFor="category" className="block text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
                Category
              </label>
              <select
                id="category"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className={`w-full px-5 py-4 rounded-2xl border ${errors.category ? 'border-red-500 focus:ring-red-500' : 'border-slate-200 dark:border-slate-700/50 focus:ring-blue-600 focus:border-blue-600'} bg-white/70 dark:bg-slate-900/50 backdrop-blur-md transition-all outline-none focus:ring-2 appearance-none`}
              >
                <option value="" disabled>Select a category</option>
                <option value="Roads & Streets">Roads & Streets</option>
                <option value="Water & Plumbing">Water & Plumbing</option>
                <option value="Electricity & Lighting">Electricity & Lighting</option>
                <option value="Parks & Recreation">Parks & Recreation</option>
                <option value="Other">Other</option>
              </select>
              {errors.category && (
                  <p className="mt-2 text-sm text-red-500 font-bold flex items-center gap-1">
                      <AlertCircle className="w-4 h-4" /> {errors.category}
                  </p>
              )}
            </div>

            {/* Location */}
            <div>
              <label className="block text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
                Location
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={getLocation}
                  className="px-5 py-4 bg-gradient-to-r from-blue-100 to-indigo-100 dark:from-blue-900/30 dark:to-indigo-900/30 text-blue-700 dark:text-blue-300 rounded-2xl font-bold hover:brightness-95 transition-all flex items-center gap-2 whitespace-nowrap"
                >
                  <MapPin className="w-4 h-4" />
                  Get GPS
                </button>
                <div className={`flex-1 flex items-center px-5 py-4 rounded-2xl border ${errors.location ? 'border-red-500' : 'border-slate-200 dark:border-slate-700/50'} bg-white/70 dark:bg-slate-900/50 text-slate-500 dark:text-slate-400 text-sm font-medium overflow-hidden text-ellipsis`}>
                  {locationStatus}
                </div>
              </div>
              {errors.location && (
                  <p className="mt-2 text-sm text-red-500 font-bold flex items-center gap-1">
                      <AlertCircle className="w-4 h-4" /> {errors.location}
                  </p>
              )}
            </div>
          </div>

          {/* Image Upload */}
          <div className="relative z-10">
            <label className="block text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
              Upload Image (Optional)
            </label>
            
            {!imagePreview ? (
                <div 
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`w-full border-2 border-dashed ${isDragging ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-900/20' : 'border-slate-300 dark:border-slate-600 bg-white/50 dark:bg-slate-800/50'} rounded-2xl p-10 flex flex-col items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer group backdrop-blur-sm`}
                >
                    <div className={`w-14 h-14 rounded-full shadow-sm flex items-center justify-center mb-4 transition-all ${isDragging ? 'bg-blue-100 scale-110' : 'bg-white dark:bg-slate-700 group-hover:scale-110 group-hover:bg-blue-50 dark:group-hover:bg-slate-600'}`}>
                        <Upload className={`w-6 h-6 ${isDragging ? 'text-blue-600' : 'text-slate-400 group-hover:text-blue-500'}`} />
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 font-bold mb-1">Click to upload or drag & drop</p>
                    <p className="text-slate-400 text-sm font-medium">PNG, JPG, GIF up to 10MB</p>
                </div>
            ) : (
                <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 aspect-video bg-black/5 w-full max-w-sm group shadow-inner">
                    <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                    <button 
                        type="button"
                        onClick={(e) => {
                            e.stopPropagation();
                            setImagePreview(null);
                            setFormData({ ...formData, image: null });
                            if (fileInputRef.current) fileInputRef.current.value = '';
                        }}
                        className="absolute top-3 right-3 bg-black/50 hover:bg-red-500 text-white p-2 rounded-full transition-all opacity-0 group-hover:opacity-100 shadow-lg backdrop-blur-md"
                    >
                        <X className="w-5 h-5" />
                    </button>
                </div>
            )}
            <input 
                type="file" 
                ref={fileInputRef} 
                onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} 
                accept="image/*" 
                className="hidden" 
            />
          </div>

          <div className="pt-6 border-t border-slate-200/50 dark:border-slate-700/50 flex flex-col-reverse sm:flex-row gap-4 mt-2 relative z-10">
            <button
                type="button"
                onClick={onCancel}
                disabled={isSubmitting}
                className="px-6 py-4 flex-1 bg-white/80 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-2xl font-bold text-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors disabled:opacity-50 shadow-sm border border-slate-200 dark:border-slate-700"
            >
                Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-4 flex-[2] bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-2xl font-bold text-lg hover:shadow-lg hover:shadow-blue-500/30 hover:-translate-y-0.5 transition-all shadow-md disabled:opacity-50 disabled:transform-none disabled:shadow-none flex justify-center items-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Submitting Report...
                </>
              ) : 'Submit Report'}
            </button>
          </div>
        </form>
      </div>
    </motion.section>
  );
}
