import React, { useState, useEffect } from 'react';
import { useAuth } from './AuthProvider';
import { Star, Send } from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, doc, setDoc, serverTimestamp } from 'firebase/firestore';

interface Review {
  id: string;
  rating: number;
  comment: string;
  authorName: string;
  authorPhoto: string | null;
  createdAt: any;
}

export default function ReviewSection({ reportId, isResolved }: { reportId: string, isResolved: boolean }) {
  const { user } = useAuth();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [hoveredStar, setHoveredStar] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const q = query(
      collection(db, 'reports', reportId, 'reviews'),
      orderBy('createdAt', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Review[];
      setReviews(fetched);
    });
    return unsubscribe;
  }, [reportId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return alert("Please log in to submit a review.");
    if (!rating) return alert("Please select a rating.");
    
    setIsSubmitting(true);
    try {
      const reviewRef = collection(db, 'reports', reportId, 'reviews');
      const reviewData = {
        rating,
        comment,
        authorId: user.uid,
        authorName: user.displayName || 'Anonymous User',
        authorPhoto: user.photoURL || null,
        createdAt: serverTimestamp()
      };

      // In a real app we'd use a transaction or cloud function to update averages
      // Here we just add the review
      await setDoc(doc(db, 'reports', reportId, 'reviews', user.uid), reviewData);
      
      setComment('');
      setRating(5);
    } catch (error: any) {
      alert("Error: " + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isResolved) {
    return (
        <div className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 mt-6 text-center">
            <p className="text-slate-500 dark:text-slate-400 font-medium">Ratings and reviews are only available after the issue has been resolved.</p>
        </div>
    );
  }

  const hasReviewed = reviews.some(r => r.id === user?.uid);

  return (
    <div className="mt-8 space-y-8">
      <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Community Ratings & Feedback</h3>
      
      {/* Review Form */}
      {user && !hasReviewed && (
        <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-4">Rate this fix</h4>
          <div className="flex gap-2 mb-4">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                className="focus:outline-none transition-transform hover:scale-110"
                onMouseEnter={() => setHoveredStar(star)}
                onMouseLeave={() => setHoveredStar(null)}
                onClick={() => setRating(star)}
              >
                <Star 
                  className={`w-8 h-8 ${((hoveredStar || rating) >= star) ? 'text-amber-400 fill-amber-400' : 'text-slate-300 dark:text-slate-700'}`} 
                />
              </button>
            ))}
          </div>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Helpful? Not quite right? Share your thoughts with the community..."
            className="w-full bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white border border-slate-200 dark:border-slate-700 rounded-xl p-4 min-h-[100px] outline-none focus:ring-2 focus:ring-blue-500 mb-4"
          ></textarea>
          <div className="flex justify-end">
            <button
              disabled={isSubmitting}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors disabled:opacity-70 flex items-center gap-2"
            >
              {isSubmitting ? 'Submitting...' : <><Send className="w-4 h-4" /> Submit Feedback</>}
            </button>
          </div>
        </form>
      )}

      {/* Reviews List */}
      <div className="space-y-4">
        {reviews.length === 0 ? (
          <p className="text-slate-500 dark:text-slate-400 italic">No reviews yet. Be the first to rate this!</p>
        ) : (
          reviews.map((review) => (
            <div key={review.id} className="bg-white dark:bg-slate-800/80 p-5 rounded-2xl border border-slate-100 dark:border-slate-700/50 flex gap-4">
              <div className="shrink-0">
                <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold overflow-hidden border border-slate-200 dark:border-slate-700">
                  {review.authorPhoto ? (
                    <img src={review.authorPhoto} alt={review.authorName} className="w-full h-full object-cover" />
                  ) : (
                    review.authorName.charAt(0).toUpperCase()
                  )}
                </div>
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h5 className="font-bold text-slate-900 dark:text-white text-sm">{review.authorName}</h5>
                    <span className="text-xs text-slate-400 dark:text-slate-500">
                      {review.createdAt ? new Date(review.createdAt.toDate()).toLocaleDateString() : 'Just now'}
                    </span>
                  </div>
                  <div className="flex bg-amber-50 dark:bg-amber-900/20 px-2 py-1 rounded-full border border-amber-100 dark:border-amber-800/50">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className={`w-3.5 h-3.5 ${review.rating >= star ? 'text-amber-500 fill-amber-500' : 'text-slate-300 dark:text-slate-700'}`} />
                    ))}
                  </div>
                </div>
                {review.comment && (
                  <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">{review.comment}</p>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
