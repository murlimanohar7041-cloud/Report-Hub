import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firebaseUtils';

interface UserProfile extends User {
  role?: 'admin' | 'user';
}

interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (e: string, p: string) => Promise<void>;
  signUpWithEmail: (e: string, p: string) => Promise<void>;
  logOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          // Fetch or create user profile
          const userRef = doc(db, 'users', firebaseUser.uid);
          let userDoc;
          try {
            userDoc = await getDoc(userRef);
          } catch (err) {
            handleFirestoreError(err, OperationType.GET, `users/${firebaseUser.uid}`);
            return;
          }
          
          if (!userDoc || !userDoc.exists()) {
            // Check if admin bootstrap
            const role = firebaseUser.email === 'murlimanohar0087@gmail.com' ? 'admin' : 'user';
            try {
              await setDoc(userRef, {
                email: firebaseUser.email,
                role,
                createdAt: serverTimestamp(),
                lastLogin: serverTimestamp()
              });
              userDoc = await getDoc(userRef);
            } catch (err) {
              handleFirestoreError(err, OperationType.WRITE, `users/${firebaseUser.uid}`);
              return;
            }
          } else {
            // Update lastLogin on every successful session auth fetch
            try {
              // use setDoc with merge to safely update without overwriting, or updateDoc
              await setDoc(userRef, {
                lastLogin: serverTimestamp(),
                displayName: firebaseUser.displayName || '',
                photoURL: firebaseUser.photoURL || ''
              }, { merge: true });
            } catch (err) {
              console.error("Error updating last login", err);
            }
          }
          
          const role = firebaseUser.email === 'murlimanohar0087@gmail.com' ? 'admin' : (userDoc?.data()?.role || 'user');
          setUser({ ...firebaseUser, role });
        } catch (error) {
          console.error("Auth flow error:", error);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const signInWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    await signInWithPopup(auth, provider);
  };

  const signInWithEmail = async (e: string, p: string) => {
    await signInWithEmailAndPassword(auth, e, p);
  };

  const signUpWithEmail = async (e: string, p: string) => {
    await createUserWithEmailAndPassword(auth, e, p);
  };

  const logOut = async () => {
    await signOut(auth);
  };

  return (
    <AuthContext.Provider value={{ user, loading, signInWithGoogle, signInWithEmail, signUpWithEmail, logOut }}>
      {children}
    </AuthContext.Provider>
  );
}
