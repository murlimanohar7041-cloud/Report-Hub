import React, { useMemo } from 'react';
import { useCollectionData } from 'react-firebase-hooks/firestore';
import { collection, query } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { Activity, CheckCircle, Clock } from 'lucide-react';
import { motion } from 'motion/react';

const COLORS = ['#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981'];

export default function AnalyticsDashboard() {
  const reportsQuery = query(collection(db, 'reports'));
  const [reports, loading] = useCollectionData(reportsQuery);

  const stats = useMemo(() => {
    if (!reports) return { total: 0, resolved: 0, pending: 0, byCategory: [] };
    
    let resolved = 0;
    let pending = 0;
    const catCount: Record<string, number> = {};

    reports.forEach((r: any) => {
      if (r.status === 'resolved') resolved++;
      else pending++;

      catCount[r.category] = (catCount[r.category] || 0) + 1;
    });

    const byCategory = Object.keys(catCount).map(key => ({
      name: key,
      value: catCount[key]
    }));

    return { total: reports.length, resolved, pending, byCategory };
  }, [reports]);

  if (loading) {
    return <div className="flex h-[80vh] items-center justify-center font-bold text-slate-500">Loading analytics...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 py-12">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="mb-10">
          <h2 className="text-3xl font-black tracking-tight uppercase text-gradient mb-2">Analytics Dashboard</h2>
          <p className="text-slate-500 dark:text-slate-400">Overview of reported issues and their current statuses.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Stat Cards */}
          <div className="glass-card p-8 rounded-3xl flex items-center gap-6">
            <div className="bg-blue-100 dark:bg-blue-900/30 p-4 rounded-2xl">
              <Activity className="w-8 h-8 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <p className="text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest text-sm">Total Reports</p>
              <h3 className="text-4xl font-black text-slate-900 dark:text-white">{stats.total}</h3>
            </div>
          </div>
          
          <div className="glass-card p-8 rounded-3xl flex items-center gap-6">
            <div className="bg-emerald-100 dark:bg-emerald-900/30 p-4 rounded-2xl">
              <CheckCircle className="w-8 h-8 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest text-sm">Resolved</p>
              <h3 className="text-4xl font-black text-slate-900 dark:text-white">{stats.resolved}</h3>
            </div>
          </div>

          <div className="glass-card p-8 rounded-3xl flex items-center gap-6">
            <div className="bg-amber-100 dark:bg-amber-900/30 p-4 rounded-2xl">
              <Clock className="w-8 h-8 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest text-sm">Pending</p>
              <h3 className="text-4xl font-black text-slate-900 dark:text-white">{stats.pending}</h3>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="glass-card p-8 rounded-3xl">
            <h3 className="text-xl font-bold mb-6 text-slate-900 dark:text-white">Reports by Category</h3>
            <div className="h-[240px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.byCategory}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {stats.byCategory.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <RechartsTooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap gap-4 mt-6 justify-center">
                {stats.byCategory.map((entry, index) => (
                    <div key={entry.name} className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                        <span className="text-sm font-medium text-slate-600 dark:text-slate-300">{entry.name}</span>
                    </div>
                ))}
            </div>
          </div>

          <div className="glass-card p-8 rounded-3xl">
             <h3 className="text-xl font-bold mb-6 text-slate-900 dark:text-white">Category Distribution (Bar)</h3>
             <div className="h-[240px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.byCategory}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" opacity={0.2} />
                  <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <RechartsTooltip 
                    cursor={{ fill: '#f1f5f9', opacity: 0.1 }}
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="value" fill="#8b5cf6" radius={[4, 4, 0, 0]}>
                    {stats.byCategory.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
             </div>
          </div>
        </div>

      </motion.div>
    </div>
  );
}
