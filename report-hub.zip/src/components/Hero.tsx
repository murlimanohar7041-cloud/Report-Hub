import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { ArrowRight, Sparkles } from 'lucide-react';

export default function Hero({ onReportClick }: { onReportClick?: () => void }) {
  const { t } = useTranslation();

  return (
    <section className="relative overflow-hidden px-4 sm:px-6 lg:px-12 py-16 sm:py-20 lg:py-36 flex flex-col items-center min-h-[70vh] sm:min-h-[85vh] justify-center text-center isolate">
      
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 -z-20">
        <img 
          src="https://images.unsplash.com/photo-1449824913935-59a10b8d2000?auto=format&fit=crop&q=80" 
          alt="City infrastructure"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-white/80 dark:bg-slate-950/80 backdrop-blur-[2px]"></div>
      </div>

      {/* Decorative animated background elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full overflow-hidden -z-10 pointer-events-none">
        <motion.div 
            animate={{ 
                scale: [1, 1.2, 1],
                opacity: [0.3, 0.4, 0.3],
            }}
            transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-40 right-[-10%] w-[40rem] h-[40rem] rounded-full bg-blue-400/20 dark:bg-blue-600/30 blur-[100px]" 
        />
        <motion.div 
            animate={{ 
                scale: [1, 1.3, 1],
                opacity: [0.2, 0.3, 0.2],
            }}
            transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            className="absolute -bottom-40 left-[-10%] w-[35rem] h-[35rem] rounded-full bg-purple-400/20 dark:bg-purple-600/30 blur-[100px]" 
        />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.6 }}
           className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-8 text-sm font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest shadow-blue-500/10"
        >
            <Sparkles className="w-4 h-4" />
            <span>Government of India Initiative</span>
        </motion.div>

        <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl sm:text-6xl md:text-7xl lg:text-[5.5rem] font-black tracking-tight leading-tight md:leading-[1] uppercase mb-6 sm:mb-8 text-slate-900 dark:text-white"
        >
          {t('Hero Title').split(',')[0]},<br/>
          <span className="text-gradient">
            {t('Hero Title').split(',')[1] || 'Your Voice'}
          </span>
        </motion.h1>
        
        <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg sm:text-xl md:text-2xl text-slate-500 dark:text-slate-400 mb-8 sm:mb-12 max-w-2xl mx-auto font-medium leading-relaxed"
        >
          {t('Hero Subtitle')}
        </motion.p>
        
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <button 
            onClick={onReportClick} 
            className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-bold text-lg hover:shadow-lg hover:shadow-blue-500/40 hover:-translate-y-1 transition-all active:scale-[0.98] flex items-center justify-center gap-2 group"
          >
            {t('Report Issue')} <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      </div>

    </section>
  );
}
