import React, { useState, useEffect, useRef } from 'react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { motion, AnimatePresence } from 'motion/react';
import { StatusBadge } from './StatusBadge';
import ReportDetailsModal from './ReportDetailsModal';
import { MousePointer2, Maximize2, Map as MapIcon, Plus, Minus } from 'lucide-react';

// Fix leaflet icon
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});


// Helper component to enable/disable map interactions dynamically
function InteractionHandler({ isActive }: { isActive: boolean }) {
  const map = useMap();

  useEffect(() => {
    if (isActive) {
      map.scrollWheelZoom.enable();
      map.dragging.enable();
      map.touchZoom.enable();
      map.doubleClickZoom.enable();
    } else {
      map.scrollWheelZoom.disable();
      map.dragging.disable();
      map.touchZoom.disable();
      map.doubleClickZoom.disable();
    }
  }, [isActive, map]);

  return null;
}

export default function MapView({ className }: { className?: string }) {
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [isMapActive, setIsMapActive] = useState(false);
  const mapRef = useRef<L.Map | null>(null);

  useEffect(() => {
    const reportsQuery = query(collection(db, 'reports'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(reportsQuery, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setReports(fetched);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const handleZoomIn = () => {
    if (mapRef.current) mapRef.current.zoomIn();
  };

  const handleZoomOut = () => {
    if (mapRef.current) mapRef.current.zoomOut();
  };

  if (loading) {
    return (
      <div className={`flex h-[80vh] items-center justify-center ${className || ''}`}>
         <div className="text-center group">
            <div className="w-16 h-16 border-4 border-slate-200 border-t-blue-600 rounded-full animate-spin mb-4 mx-auto"></div>
            <p className="text-slate-500 font-bold animate-pulse">Initializing Civic Map...</p>
         </div>
      </div>
    );
  }

  // Assuming India center
  const center: [number, number] = [20.5937, 78.9629];

  return (
    <motion.section 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`w-full relative z-0 group ${className || 'h-[calc(100vh-80px)]'}`}
    >
      <div className="absolute top-4 left-4 z-[400] flex flex-col gap-2">
         <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md p-3 rounded-2xl shadow-xl border border-white/20 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-200 dark:shadow-none">
               <MapIcon className="w-5 h-5 text-white" />
            </div>
            <div>
               <h3 className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-tight leading-none">Civic Network</h3>
               <p className="text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest mt-1">Live Incidents</p>
            </div>
         </div>
         
         <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm px-3 py-2 rounded-xl shadow-lg border border-white/10 flex items-center gap-4">
             <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase">Resolved</span>
             </div>
             <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase">Pending</span>
             </div>
         </div>
      </div>

      {/* Manual Zoom Controls */}
      <div className="absolute right-4 top-4 z-[400] flex flex-col gap-2">
          <button 
            onClick={handleZoomIn}
            className="w-10 h-10 bg-white dark:bg-slate-900 rounded-xl shadow-xl flex items-center justify-center border border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all active:scale-95 text-slate-900 dark:text-white"
          >
            <Plus className="w-5 h-5" />
          </button>
          <button 
            onClick={handleZoomOut}
            className="w-10 h-10 bg-white dark:bg-slate-900 rounded-xl shadow-xl flex items-center justify-center border border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all active:scale-95 text-slate-900 dark:text-white"
          >
            <Minus className="w-5 h-5" />
          </button>
      </div>

      <div className="w-full h-full rounded-3xl overflow-hidden shadow-2xl border-4 border-white dark:border-slate-800 relative">
        {!isMapActive && (
          <div 
            onClick={() => setIsMapActive(true)}
            className="absolute inset-0 z-[500] bg-slate-900/10 backdrop-blur-[2px] transition-all hover:bg-slate-900/20 cursor-pointer flex items-center justify-center group/overlay"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white dark:bg-slate-900 px-6 py-4 rounded-3xl shadow-2xl border border-white/20 flex flex-col items-center gap-3 max-w-[280px] text-center"
            >
              <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center group-hover/overlay:rotate-12 transition-transform">
                <MousePointer2 className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-slate-900 dark:text-white font-black uppercase text-sm leading-tight">Interact with Map</p>
                <p className="text-slate-500 dark:text-slate-400 text-[10px] mt-1 font-bold uppercase tracking-widest">Click to start exploring</p>
              </div>
            </motion.div>
          </div>
        )}

        <MapContainer 
          center={center} 
          zoom={5} 
          scrollWheelZoom={false}
          dragging={false}
          touchZoom={false}
          doubleClickZoom={false}
          zoomControl={false}
          ref={(m) => { if (m) mapRef.current = m; }}
          style={{ height: '100%', width: '100%', zIndex: 0 }}
        >
          <InteractionHandler isActive={isMapActive} />
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          
          {reports?.map((report: any) => {
             if (report.location && report.location.lat && report.location.lng) {
               return (
                  <Marker key={report.id} position={[report.location.lat, report.location.lng]}>
                    <Popup className="rounded-2xl overflow-hidden min-w-[240px] border-none p-0 custom-popup shadow-2xl">
                      <div className="font-sans bg-white p-4">
                          <div className="flex justify-between items-start mb-3">
                             <span className="text-[10px] font-black uppercase tracking-widest text-blue-600">{report.category}</span>
                             <div className="scale-75 origin-top-right">
                               <StatusBadge status={report.status} />
                             </div>
                          </div>
                          <h3 className="font-black text-slate-950 leading-tight mb-2 text-base">{report.title}</h3>
                          <p className="text-slate-500 text-xs mb-4 line-clamp-2 leading-relaxed">
                            {report.description || 'Reported incident currently under civic review and resolution protocol.'}
                          </p>
                          <button 
                              onClick={() => setSelectedReport(report)}
                              className="w-full bg-slate-950 hover:bg-slate-800 text-white font-black py-2.5 px-4 rounded-xl transition-all text-[11px] uppercase tracking-widest flex items-center justify-center gap-2"
                          >
                              <Maximize2 className="w-3.5 h-3.5" />
                              View Full Protocol
                          </button>
                      </div>
                    </Popup>
                  </Marker>
               )
             }
             return null;
          })}
        </MapContainer>
        
        {isMapActive && (
          <button 
            onClick={() => setIsMapActive(false)}
            className="absolute bottom-4 left-1/2 -translate-x-1/2 z-[400] bg-slate-900 border border-slate-800 text-white px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-2xl hover:bg-slate-800 transition-colors"
          >
            Lock Navigation
          </button>
        )}
      </div>
      
      <AnimatePresence>
        {selectedReport && (
            <ReportDetailsModal
                report={selectedReport}
                onClose={() => setSelectedReport(null)}
            />
        )}
      </AnimatePresence>
    </motion.section>
  );
}
