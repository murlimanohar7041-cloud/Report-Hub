import { useState, useEffect } from 'react';
import { collection, query, orderBy, onSnapshot, doc, setDoc, deleteDoc, serverTimestamp, getDoc, updateDoc, increment } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthProvider';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import ReportCard from './ReportCard';
import SkeletonCard from './SkeletonCard';
import ReportDetailsModal from './ReportDetailsModal';
import LottieEmpty from './LottieEmpty';

const CATEGORIES = ['All', 'Roads & Streets', 'Water & Plumbing', 'Electricity & Lighting', 'Parks & Recreation', 'Other'];

export default function ReportsList() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState<any>(null);

  useEffect(() => {
    const q = query(collection(db, 'reports'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedReports = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        timeAgo: doc.data().createdAt ? new Date(doc.data().createdAt.toDate()).toLocaleDateString() : 'Just now'
      }));
      setReports(fetchedReports);
      setLoading(false);
      
      // Update selected report if it's currently open
      setSelectedReport((prev: any) => {
          if (prev) {
             const updated = fetchedReports.find(r => r.id === prev.id);
             return updated || prev;
          }
          return prev;
      });
    });
    return unsubscribe;
  }, []);

  const handleUpvote = async (reportId: string, authorId: string, currentUpvotes: number) => {
    if (!user) {
      alert("Please login to upvote");
      return;
    }
    
    const upvoteRef = doc(db, `reports/${reportId}/upvotes/${user.uid}`);
    const upvoteSnap = await getDoc(upvoteRef);
    const reportRef = doc(db, 'reports', reportId);

    if (upvoteSnap.exists()) {
      await deleteDoc(upvoteRef);
      await updateDoc(reportRef, { upvoteCount: increment(-1) });
    } else {
      await setDoc(upvoteRef, { createdAt: serverTimestamp() });
      await updateDoc(reportRef, { upvoteCount: increment(1) });
    }
  };

  const filteredReports = reports.filter((report) => 
    selectedCategory === 'All' || report.category === selectedCategory
  );

  return (
    <section className="py-12 relative z-10 min-h-[80vh]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="mb-8 sm:mb-12">
          <h2 className="text-3xl md:text-5xl font-black tracking-tight uppercase text-gradient mb-4">{t('All Reports')}</h2>
          <p className="text-base sm:text-xl text-slate-500 dark:text-slate-400 font-medium">Browse all community reports and track their resolution status.</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 sm:gap-3 mb-8 sm:mb-10">
          {CATEGORIES.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 sm:px-5 py-2 sm:py-2.5 rounded-full text-xs sm:text-sm font-bold uppercase tracking-wider transition-all border shadow-sm ${
                selectedCategory === category
                  ? 'bg-blue-600 text-white border-blue-600 shadow-blue-500/30'
                  : 'bg-white/70 dark:bg-slate-900/50 backdrop-blur-md text-slate-500 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
             {Array(6).fill(0).map((_, i) => <SkeletonCard key={i} />)}
        </div>
        ) : (
        <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          <AnimatePresence>
            {filteredReports.map((report) => (
              <ReportCard 
                key={report.id} 
                report={report} 
                onClick={() => setSelectedReport(report)} 
                onUpvote={handleUpvote}
              />
            ))}
          </AnimatePresence>
          {filteredReports.length === 0 && (
            <motion.div initial={{opacity:0}} animate={{opacity:1}} layout className="col-span-full">
              <LottieEmpty message="No reports found in this category." />
            </motion.div>
          )}
        </motion.div>
        )}
      </div>

      <AnimatePresence>
        {selectedReport && (
          <ReportDetailsModal
            report={selectedReport}
            onClose={() => setSelectedReport(null)}
            onUpvote={handleUpvote}
          />
        )}
      </AnimatePresence>
    </section>
  );
}
