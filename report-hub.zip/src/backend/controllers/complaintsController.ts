import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
import { getAdminApp } from '../config/firebaseAdmin';

export const createComplaint = async (req: AuthRequest, res: Response) => {
  try {
    const { title, description, category, imageUrl, location } = req.body;
    const { adminDb } = getAdminApp();

    if (!adminDb) {
      return res.status(500).json({ success: false, message: 'Backend not fully configured.' });
    }

    if (!title || !description || !category) {
      return res.status(400).json({ success: false, message: 'Title, description, and category are required' });
    }

    const complaintData = {
      title,
      description,
      category,
      imageUrl: imageUrl || null,
      location: location || null,
      status: 'open',
      createdAt: new Date(),
      authorId: req.user!.uid,
      upvoteCount: 0,
      upvotedBy: []
    };

    const docRef = await adminDb.collection('reports').add(complaintData);

    return res.status(201).json({
      success: true,
      message: 'Complaint submitted successfully',
      data: { id: docRef.id, ...complaintData }
    });
  } catch (error: any) {
    console.error('Error creating complaint:', error);
    return res.status(500).json({ success: false, message: 'Internal server error', error: error.message });
  }
};

export const getComplaints = async (req: AuthRequest, res: Response) => {
  try {
    const { category, status, sortBy, order = 'desc', limit = '50' } = req.query;
    const { adminDb } = getAdminApp();

    if (!adminDb) return res.status(500).json({ success: false, message: 'Backend not configured.' });

    let query: any = adminDb.collection('reports');

    if (category && category !== 'All') {
      query = query.where('category', '==', category);
    }
    if (status) {
      query = query.where('status', '==', status);
    }

    // Sort by latest (createdAt) or most upvoted (upvoteCount)
    if (sortBy === 'upvotes') {
      query = query.orderBy('upvoteCount', order as string);
    } else {
      query = query.orderBy('createdAt', order as string);
    }

    query = query.limit(parseInt(limit as string));

    const snapshot = await query.get();
    const complaints = snapshot.docs.map((doc: any) => ({
      id: doc.id,
      ...doc.data(),
      // Format timestamps if needed, or send as milliseconds
      createdAt: doc.data().createdAt?.toMillis ? doc.data().createdAt.toMillis() : doc.data().createdAt
    }));

    return res.status(200).json({
      success: true,
      message: 'Complaints fetched successfully',
      data: complaints
    });
  } catch (error: any) {
    console.error('Error fetching complaints:', error);
    return res.status(500).json({ success: false, message: 'Internal server error', error: error.message });
  }
};

export const upvoteComplaint = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { adminDb } = getAdminApp();

    if (!adminDb) return res.status(500).json({ success: false, message: 'Backend not configured.' });

    const docRef = adminDb.collection('reports').doc(id);
    const doc = await docRef.get();

    if (!doc.exists) {
      return res.status(404).json({ success: false, message: 'Complaint not found' });
    }

    const data = doc.data()!;
    const upvotedBy = data.upvotedBy || [];
    const userId = req.user!.uid;

    if (upvotedBy.includes(userId)) {
      return res.status(400).json({ success: false, message: 'User has already upvoted this complaint' });
    }

    await docRef.update({
      upvoteCount: (data.upvoteCount || 0) + 1,
      upvotedBy: [...upvotedBy, userId]
    });

    return res.status(200).json({ success: true, message: 'Complaint upvoted successfully' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Internal server error', error: error.message });
  }
};

export const updateStatus = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const { adminDb } = getAdminApp();

    if (!adminDb) return res.status(500).json({ success: false, message: 'Backend not configured.' });

    const validStatuses = ['open', 'processing', 'resolved', 'rejected'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status' });
    }

    const docRef = adminDb.collection('reports').doc(id);
    await docRef.update({ status });

    // Optional: Add notification logic here (e.g. inserting into a 'notifications' collection for the user)
    const complaint = await docRef.get();
    if (complaint.exists) {
      const authorId = complaint.data()?.authorId;
      if (authorId) {
          await adminDb.collection('notifications').add({
              userId: authorId,
              reportId: id,
              message: `The status of your report "${complaint.data()?.title}" has been updated to ${status}.`,
              createdAt: new Date(),
              read: false
          });
      }
    }

    return res.status(200).json({ success: true, message: 'Status updated successfully' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Internal server error', error: error.message });
  }
};

export const addReview = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { rating, comment, authorName, authorPhoto } = req.body;
    const { adminDb } = getAdminApp();

    if (!adminDb) return res.status(500).json({ success: false, message: 'Backend not configured.' });

    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ success: false, message: 'Valid rating (1-5) is required' });
    }

    const docRef = adminDb.collection('reports').doc(id);
    const doc = await docRef.get();

    if (!doc.exists) {
      return res.status(404).json({ success: false, message: 'Complaint not found' });
    }

    const data = doc.data()!;
    if (data.status !== 'resolved') {
      return res.status(400).json({ success: false, message: 'Can only review resolved complaints' });
    }

    const userId = req.user!.uid;
    const reviewRef = docRef.collection('reviews').doc(userId);
    const reviewDoc = await reviewRef.get();
    
    let isNewReview = !reviewDoc.exists;
    let oldRating = isNewReview ? 0 : reviewDoc.data()?.rating || 0;

    const currentCount = data.reviewCount || 0;
    const currentTotal = (data.averageRating || 0) * currentCount;
    
    let newCount = isNewReview ? currentCount + 1 : currentCount;
    let newTotal = isNewReview ? currentTotal + rating : currentTotal - oldRating + rating;
    let newAverage = newCount === 0 ? 0 : newTotal / newCount;

    const batch = adminDb.batch();

    batch.set(reviewRef, {
      rating,
      comment: comment || '',
      authorId: userId,
      authorName: authorName || 'Anonymous User',
      authorPhoto: authorPhoto || null,
      createdAt: new Date(),
    });

    batch.update(docRef, {
      reviewCount: newCount,
      averageRating: newAverage
    });

    await batch.commit();

    return res.status(200).json({ success: true, message: 'Review added successfully', averageRating: newAverage });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Internal server error', error: error.message });
  }
};

export const deleteComplaint = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { adminDb } = getAdminApp();

    if (!adminDb) return res.status(500).json({ success: false, message: 'Backend not configured.' });

    await adminDb.collection('reports').doc(id).delete();
    return res.status(200).json({ success: true, message: 'Complaint deleted successfully' });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Internal server error', error: error.message });
  }
};

