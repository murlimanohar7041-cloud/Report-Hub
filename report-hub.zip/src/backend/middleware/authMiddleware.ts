import { Request, Response, NextFunction } from 'express';
import { getAdminApp } from '../config/firebaseAdmin';

export interface AuthRequest extends Request {
  user?: {
    uid: string;
    email?: string;
    role?: string;
  };
}

export const verifyToken = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'Unauthorized: No token provided' });
  }

  const token = authHeader.split('Bearer ')[1];
  const { adminAuth, adminDb } = getAdminApp();

  if (!adminAuth || !adminDb) {
    return res.status(500).json({ success: false, message: 'Backend not fully configured (missing service account).' });
  }

  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    
    // Check if user is admin (assuming role is stored in user profile document)
    // Wait, let's just fetch their doc to see if role is admin.
    let role = 'user';
    try {
        const userDoc = await adminDb.collection('users').doc(decodedToken.uid).get();
        if (userDoc.exists) {
            role = userDoc.data()?.role || 'user';
        }
    } catch (err) {
        console.error("Error fetching user role:", err);
    }
    
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email,
      role: role
    };
    next();
  } catch (error) {
    console.error('Error verifying token:', error);
    return res.status(403).json({ success: false, message: 'Unauthorized: Invalid token' });
  }
};

export const requireAdmin = (req: AuthRequest, res: Response, next: NextFunction) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Forbidden: Admin access required' });
  }
  next();
};
