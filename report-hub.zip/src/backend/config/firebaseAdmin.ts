import * as admin from 'firebase-admin';

let adminDb: admin.firestore.Firestore | null = null;
let adminAuth: admin.auth.Auth | null = null;
let adminStorage: admin.storage.Storage | null = null;

export function getAdminApp() {
  if (adminDb && adminAuth && adminStorage) {
    return { adminDb, adminAuth, adminStorage };
  }

  const serviceAccountString = process.env.FIREBASE_SERVICE_ACCOUNT;
  if (!serviceAccountString) {
    console.warn('⚠️ FIREBASE_SERVICE_ACCOUNT environment variable is not set. Backend APIs will not function fully.');
    return { adminDb: null, adminAuth: null, adminStorage: null };
  }

  if (!admin.apps.length) {
    try {
      const serviceAccount = JSON.parse(serviceAccountString);
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        // storageBucket: process.env.FIREBASE_STORAGE_BUCKET || 'your-project.appspot.com' 
      });
      console.log('✅ Firebase Admin SDK initialized successfully');
    } catch (e) {
      console.error('❌ Failed to parse FIREBASE_SERVICE_ACCOUNT JSON:', e);
      return { adminDb: null, adminAuth: null, adminStorage: null };
    }
  }

  adminDb = admin.firestore();
  adminAuth = admin.auth();
  adminStorage = admin.storage();

  return { adminDb, adminAuth, adminStorage };
}
