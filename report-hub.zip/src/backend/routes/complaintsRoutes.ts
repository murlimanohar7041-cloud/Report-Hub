import { Router } from 'express';
import { 
  createComplaint, 
  getComplaints, 
  upvoteComplaint, 
  updateStatus, 
  deleteComplaint,
  addReview
} from '../controllers/complaintsController';
import { verifyToken, requireAdmin } from '../middleware/authMiddleware';
import { apiLimiter, createComplaintLimiter } from '../middleware/rateLimit';

const router = Router();

// Apply general rate limits to all routes inside this file
router.use(apiLimiter);

// Public or basic authenticated read route (you can make this public if desired by removing verifyToken)
router.get('/', getComplaints);

// Authenticated user routes
router.post('/', verifyToken, createComplaintLimiter, createComplaint);
router.post('/:id/upvote', verifyToken, upvoteComplaint);
router.post('/:id/reviews', verifyToken, addReview);

// Admin only routes
router.patch('/:id/status', verifyToken, requireAdmin, updateStatus);
router.delete('/:id', verifyToken, requireAdmin, deleteComplaint);

export default router;
