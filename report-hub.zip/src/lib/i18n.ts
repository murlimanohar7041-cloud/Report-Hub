import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  en: {
    translation: {
      'Home': 'Home',
      'All Reports': 'All Reports',
      'Admin Dashboard': 'Admin Dashboard',
      'Login': 'Login',
      'Logout': 'Logout',
      'Report Issue': 'Report Issue',
      'Hero Title': 'Report Hub: Your City, Your Voice',
      'Hero Subtitle': 'Report non-emergency issues securely and locally to help improve our community with Report Hub. Track the progress in real-time.',
      'Recent Reports': 'Recent Reports',
      'Category': 'Category',
      'Location': 'Location',
      'Description': 'Description',
      'Submit Report': 'Submit Report',
      'Analytics': 'Analytics',
      'Map': 'Map View'
    }
  },
  hi: {
    translation: {
      'Home': 'मुख्य पृष्ठ',
      'All Reports': 'सभी रिपोर्ट',
      'Admin Dashboard': 'व्यवस्थापक डैशबोर्ड',
      'Login': 'लॉग इन करें',
      'Logout': 'लॉग आउट',
      'Report Issue': 'समस्या दर्ज करें',
      'Hero Title': 'रिपोर्ट हब: आपका शहर, आपकी आवाज़',
      'Hero Subtitle': 'रिपोर्ट हब के साथ अपने समुदाय को बेहतर बनाने में मदद करने के लिए सुरक्षित रूप से गैर-आपातकालीन समस्याओं की रिपोर्ट करें। वास्तविक समय में प्रगति को ट्रैक करें।',
      'Recent Reports': 'हाल की रिपोर्ट',
      'Category': 'श्रेणी',
      'Location': 'स्थान',
      'Description': 'विवरण',
      'Submit Report': 'रिपोर्ट जमा करें',
      'Analytics': 'एनालिटिक्स',
      'Map': 'मानचित्र दृश्य'
    }
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false, // not needed for react as it escapes by default
    }
  });

export default i18n;
