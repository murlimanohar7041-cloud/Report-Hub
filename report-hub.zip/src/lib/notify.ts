import toast from 'react-hot-toast';
import { playSound } from './sounds';
import { db } from './firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

interface NotifyOptions {
  message: string;
  type?: 'success' | 'error' | 'info';
  sound?: boolean;
  saveToDb?: boolean;
  userId?: string;
  reportId?: string;
}

export const notify = async ({ 
  message, 
  type = 'success', 
  sound = true,
  saveToDb = false,
  userId,
  reportId 
}: NotifyOptions) => {
  if (sound) {
    playSound('notify');
  }

  if (type === 'success') {
    toast.success(message);
  } else if (type === 'error') {
    toast.error(message);
  } else {
    toast(message);
  }

  // Also store in the user's notification bar in DB if needed
  if (saveToDb && userId) {
    try {
      await addDoc(collection(db, 'notifications'), {
        userId,
        reportId: reportId || null,
        reportTitle: message,
        newStatus: 'notification',
        read: false,
        createdAt: serverTimestamp()
      });
    } catch (e) {
      console.error('Error saving notification', e);
    }
  }
};
