import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId); // CRITICAL: The app will break without this line

async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test-connection', 'probe'));
  } catch (error) {
    if(error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration or Internet connection. Firestore reported offline.");
    } else {
      console.warn("Initial Firestore connection probe failed (expected if collection doesn't exist, but connection itself should work):", error);
    }
  }
}
testConnection();
