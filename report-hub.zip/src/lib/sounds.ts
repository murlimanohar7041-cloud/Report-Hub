
export const playSound = (type: 'success' | 'click' | 'open' | 'admin' | 'submit' | 'notify') => {
  const sounds = {
    success: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3',
    click: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
    open: 'https://assets.mixkit.co/active_storage/sfx/2567/2567-preview.mp3',
    admin: 'https://assets.mixkit.co/active_storage/sfx/2569/2569-preview.mp3', // Short UI tap
    submit: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3', // Short success bell
    notify: 'https://assets.mixkit.co/active_storage/sfx/2854/2854-preview.mp3' // Quick pop/notification sound
  };

  try {
    const audio = new Audio(sounds[type]);
    audio.play().catch(e => console.warn('Audio play blocked:', e));
  } catch (e) {
    console.error('Sound error:', e);
  }
};
