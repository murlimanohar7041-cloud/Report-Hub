/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin } from 'lucide-react';
import Header from './components/Header';
import Hero from './components/Hero';
import RecentReports from './components/RecentReports';
import TopRatedReports from './components/TopRatedReports';
import Footer from './components/Footer';
import ReportForm from './components/ReportForm';
import ReportsList from './components/ReportsList';
import AdminDashboard from './components/AdminDashboard';
import UserDashboard from './components/UserDashboard';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import MapView from './components/MapView';
import About from './components/About';
import { Toaster } from 'react-hot-toast';
import { useAuth } from './components/AuthProvider';
import { playSound } from './lib/sounds';

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'report' | 'all-reports' | 'admin' | 'dashboard' | 'analytics' | 'map' | 'about'>('home');
  const { user } = useAuth();

  const handleNavigate = (view: typeof currentView) => {
    if (view === 'admin') {
      playSound('admin');
    } else {
      playSound('click');
    }
    setCurrentView(view);
  };

  const handleReportClick = () => {
    playSound('click');
    if (user) {
      setCurrentView('report');
    } else {
      alert("Please login to report an issue.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-300">
      <Toaster position="top-center" toastOptions={{ className: 'dark:bg-slate-800 dark:text-white rounded-2xl font-bold shadow-xl border border-slate-100 dark:border-slate-700' }} />
      <Header 
        onReportClick={handleReportClick} 
        onHomeClick={() => handleNavigate('home')} 
        onAllReportsClick={() => handleNavigate('all-reports')}
        onAdminClick={() => handleNavigate('admin')}
        onAnalyticsClick={() => handleNavigate('analytics')}
        onMapClick={() => handleNavigate('map')}
        onDashboardClick={() => handleNavigate('dashboard')}
        onAboutClick={() => handleNavigate('about')}
      />
      <main className="flex-1 relative">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5 dark:opacity-[0.02] pointer-events-none"></div>
        {currentView === 'home' && (
          <>
            <Hero onReportClick={handleReportClick} />
            
            {/* Quick Links / Explore Section */}
            <div className="py-8 bg-slate-50 dark:bg-slate-950">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <button onClick={() => handleNavigate('all-reports')} className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl hover:shadow-xl hover:-translate-y-1 transition-all duration-300 text-left group">
                    <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">All Reports</h3>
                    <p className="text-slate-500 dark:text-slate-400 text-sm">Browse all community reported issues.</p>
                  </button>

                  <button onClick={() => handleNavigate('map')} className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl hover:shadow-xl hover:-translate-y-1 transition-all duration-300 text-left group">
                    <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"></polygon><line x1="9" y1="3" x2="9" y2="18"></line><line x1="15" y1="6" x2="15" y2="21"></line></svg>
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Map View</h3>
                    <p className="text-slate-500 dark:text-slate-400 text-sm">Explore reported issues geographically.</p>
                  </button>

                  <button onClick={() => handleNavigate('analytics')} className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl hover:shadow-xl hover:-translate-y-1 transition-all duration-300 text-left group">
                    <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v18h18"></path><path d="M18 17V9"></path><path d="M13 17V5"></path><path d="M8 17v-3"></path></svg>
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Analytics</h3>
                    <p className="text-slate-500 dark:text-slate-400 text-sm">View statistics and issue resolution trends.</p>
                  </button>
                </div>
              </div>
            </div>

            <RecentReports onViewAllClick={() => handleNavigate('all-reports')} />
            <TopRatedReports />
            
            {/* Map View Section added inside Home */}
            <div className="py-12 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
               <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 mb-8">
                 <h2 className="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Interactive Map</h2>
                 <p className="text-slate-600 dark:text-slate-400 mt-2">Explore reported issues in your area.</p>
               </div>
               <MapView className="h-[600px]" />
            </div>

            {/* Analytics Dashboard Section added inside Home */}
            <div className="border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
               <AnalyticsDashboard />
            </div>

            {/* All Reports Section added inside Home */}
            <div className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
               <ReportsList />
            </div>
          </>
        )}
        {currentView === 'report' && (
          <ReportForm onCancel={() => handleNavigate('home')} />
        )}
        {currentView === 'all-reports' && (
          <ReportsList />
        )}
        {currentView === 'admin' && user?.role === 'admin' && (
          <AdminDashboard />
        )}
        {currentView === 'dashboard' && (
          <UserDashboard />
        )}
        {currentView === 'analytics' && (
          <AnalyticsDashboard />
        )}
        {currentView === 'map' && (
          <MapView />
        )}
        {currentView === 'about' && (
          <About />
        )}

        {/* Floating Action Button for Mobile */}
        <AnimatePresence>
          {currentView !== 'report' && (
            <motion.button
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleReportClick}
              className="lg:hidden fixed bottom-6 right-6 z-40 w-14 h-14 bg-gradient-to-br from-blue-600 to-purple-600 text-white rounded-full shadow-2xl flex items-center justify-center border-4 border-white dark:border-slate-900"
            >
              <MapPin className="w-6 h-6" />
            </motion.button>
          )}
        </AnimatePresence>
      </main>
      <Footer />
    </div>
  );
}
